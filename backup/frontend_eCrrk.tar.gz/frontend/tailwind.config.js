/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: '#07C160',
        secondary: '#576B95',
        wechat: {
          green: '#07C160',
          blue: '#576B95',
          gray: '#EDEDED',
          darkgray: '#C0C0C0'
        }
      }
    },
  },
  plugins: [],
}

