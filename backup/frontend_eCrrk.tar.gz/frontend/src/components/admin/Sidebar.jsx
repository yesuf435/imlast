import React from 'react';

const Sidebar = ({ activeModule, onModuleChange, collapsed, onToggle }) => {
  const modules = [
    { id: 'monitoring', name: '智能监控中心', icon: '📊' },
    { id: 'customers', name: '客户关系管理', icon: '👥' },
    { id: 'chat-analysis', name: '对话智能分析', icon: '💬' },
    { id: 'data-insights', name: '数据洞察中心', icon: '📈' },
    { id: 'system-config', name: '系统智能配置', icon: '⚙️' },
    { id: 'ai-assistant', name: 'AI智能助手', icon: '🤖' },
  ];

  return (
    <div className={`fixed left-0 top-0 h-full bg-gray-800 border-r border-gray-700 transition-all duration-300 z-50 ${
      collapsed ? 'w-16' : 'w-64'
    }`}>
      {/* Logo */}
      <div className="p-4 border-b border-gray-700">
        <div className="flex items-center gap-3">
          <span className="text-2xl">🏛️</span>
          {!collapsed && (
            <div>
              <h2 className="text-lg font-bold">佳士得</h2>
              <p className="text-xs text-gray-400">管理平台</p>
            </div>
          )}
        </div>
      </div>

      {/* Toggle Button */}
      <button
        onClick={onToggle}
        className="absolute -right-3 top-4 w-6 h-6 bg-gray-700 hover:bg-gray-600 rounded-full flex items-center justify-center transition-colors"
      >
        <svg className={`w-4 h-4 transition-transform ${collapsed ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
        </svg>
      </button>

      {/* Navigation */}
      <nav className="p-4 space-y-2">
        {modules.map((module) => (
          <button
            key={module.id}
            onClick={() => onModuleChange(module.id)}
            className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-all duration-200 ${
              activeModule === module.id
                ? 'bg-blue-600 text-white'
                : 'text-gray-300 hover:bg-gray-700 hover:text-white'
            }`}
            title={collapsed ? module.name : ''}
          >
            <span className="text-lg">{module.icon}</span>
            {!collapsed && (
              <span className="text-sm font-medium">{module.name}</span>
            )}
          </button>
        ))}
      </nav>

      {/* System Status */}
      {!collapsed && (
        <div className="absolute bottom-4 left-4 right-4">
          <div className="bg-gray-700 rounded-lg p-3">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-xs text-gray-300">系统状态</span>
            </div>
            <div className="text-xs text-gray-400">
              <div>CPU: 23%</div>
              <div>内存: 67%</div>
              <div>网络: 正常</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Sidebar;
