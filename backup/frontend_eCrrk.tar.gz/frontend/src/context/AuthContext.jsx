import React, { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';
import io from 'socket.io-client';

const AuthContext = createContext();

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [socket, setSocket] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (token) {
      // Set axios default header and baseURL
      axios.defaults.baseURL = 'http://8.148.77.51:3001';
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      
      // Connect socket
      const newSocket = io('http://8.148.77.51:3001', {
        auth: { token }
      });

      newSocket.on('connect', () => {
        console.log('Socket connected');
      });

      newSocket.on('connect_error', (error) => {
        console.error('Socket connection error:', error);
      });

      setSocket(newSocket);

      // Get user info from token
      try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        setUser({
          id: payload.id,
          username: payload.username
        });
      } catch (error) {
        console.error('Invalid token');
        logout();
      }

      setLoading(false);

      return () => {
        newSocket.disconnect();
      };
    } else {
      setLoading(false);
    }
  }, [token]);

  const login = (token, userData) => {
    localStorage.setItem('token', token);
    setToken(token);
    setUser(userData);
  };

  const logout = () => {
    localStorage.removeItem('token');
    setToken(null);
    setUser(null);
    if (socket) {
      socket.disconnect();
    }
  };

  const register = (token, userData) => {
    localStorage.setItem('token', token);
    setToken(token);
    setUser(userData);
  };

  return (
    <AuthContext.Provider value={{ user, token, socket, login, logout, register, loading }}>
      {!loading && children}
    </AuthContext.Provider>
  );
};

