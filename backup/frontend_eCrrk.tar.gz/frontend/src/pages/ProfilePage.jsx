import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';

const ProfilePage = () => {
  const { user, logout } = useAuth();
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  const menuItems = [
    {
      id: 'collection',
      title: '我的收藏',
      action: () => console.log('我的收藏')
    },
    {
      id: 'transactions',
      title: '交易记录',
      action: () => console.log('交易记录')
    },
    {
      id: 'preferences',
      title: '服务偏好',
      action: () => console.log('服务偏好')
    },
    {
      id: 'privacy',
      title: '隐私设置',
      action: () => console.log('隐私设置')
    },
    {
      id: 'notifications',
      title: '通知设置',
      action: () => console.log('通知设置')
    },
    {
      id: 'about',
      title: '关于佳士得',
      action: () => console.log('关于佳士得')
    },
    {
      id: 'contact',
      title: '联系客服',
      action: () => console.log('联系客服')
    }
  ];

  const handleLogout = () => {
    setShowLogoutConfirm(true);
  };

  const confirmLogout = () => {
    logout();
    setShowLogoutConfirm(false);
  };

  // 模拟客户等级
  const clientLevel = Math.random() > 0.5 ? 'vip' : 'premium';
  const clientLevelText = clientLevel === 'vip' ? '重要客户' : '尊贵客户';

  return (
    <div className="h-full warm-cream pb-16">
      {/* Header */}
      <div className="soft-blue-bg text-white px-6 py-4 safe-area-pt shadow-gentle">
        <h1 className="text-hierarchy-1 text-white">我的</h1>
      </div>
      
      {/* User Profile Card */}
      <div className="p-6">
        <div className="soft-card p-6 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-warm-gold/5 to-soft-blue/5"></div>
          <div className="relative flex items-center gap-4">
            <div className="relative">
              <img
                src={user?.avatar || 'https://ui-avatars.com/api/?background=1A365D&color=fff&name=User'}
                alt="用户头像"
                className="avatar-soft"
              />
              <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-green-500 rounded-full border-2 border-white breathing"></div>
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <div className="text-hierarchy-2 text-primary">{user?.username || '123123'}</div>
                <span className="text-hierarchy-4 text-muted">·</span>
                <div className={`px-2 py-1 rounded-soft text-xs font-medium ${
                  clientLevel === 'vip' 
                    ? 'bg-gradient-to-r from-warm-gold to-yellow-600 text-white' 
                    : 'bg-gradient-to-r from-soft-blue to-blue-600 text-white'
                }`}>
                  {clientLevelText}
                </div>
              </div>
              <div className="text-hierarchy-4 text-muted mb-1">ID: CS{user?.id || '68e9c25e1e57e38d34e0d1f2'}</div>
              <div className="flex items-center gap-2">
                <span className="text-green-500 text-sm">●</span>
                <span className="text-hierarchy-4 text-green-600">在线</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Menu Items */}
      <div className="px-6">
        <div className="soft-card overflow-hidden">
          {menuItems.map((item, index) => (
            <div key={item.id}>
              <button
                onClick={item.action}
                className="w-full flex items-center justify-between p-4 hover:bg-gray-50 transition-all duration-300 group list-item-soft"
              >
                <span className="text-hierarchy-3 text-primary group-hover:text-warm-gold transition-colors">
                  {item.title}
                </span>
                <span className="text-muted group-hover:text-warm-gold transition-colors text-lg">
                  ›
                </span>
              </button>
              {index < menuItems.length - 1 && (
                <div className="divider-soft mx-4"></div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Logout Button */}
      <div className="mt-8 px-6">
        <button
          onClick={handleLogout}
          className="w-full bg-red-500 text-white py-4 rounded-button hover:bg-red-600 transition-all duration-300 flex items-center justify-center gap-2 shadow-gentle hover:scale-105"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
          </svg>
          <span className="text-hierarchy-3 font-medium">退出登录</span>
        </button>
      </div>

      {/* Logout Confirmation Modal */}
      {showLogoutConfirm && (
        <div className="modal-overlay-soft">
          <div className="modal-content-soft">
            <div className="text-center">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
                </svg>
              </div>
              <h3 className="text-hierarchy-1 text-primary mb-2">确认退出</h3>
              <p className="text-hierarchy-3 text-secondary mb-6">您确定要退出佳士得专属服务吗？</p>
              <div className="flex gap-3">
                <button
                  onClick={() => setShowLogoutConfirm(false)}
                  className="flex-1 btn-ghost"
                >
                  取消
                </button>
                <button
                  onClick={confirmLogout}
                  className="flex-1 bg-red-500 text-white rounded-button hover:bg-red-600 transition-colors"
                >
                  确认退出
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProfilePage;
