import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';

const MessagesPage = () => {
  const [chats, setChats] = useState([]);
  const [users, setUsers] = useState([]);
  const [showAddFriend, setShowAddFriend] = useState(false);
  const [showCreateGroup, setShowCreateGroup] = useState(false);
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [groupName, setGroupName] = useState('');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [pullDistance, setPullDistance] = useState(0);
  const [startY, setStartY] = useState(0);
  const [isPulling, setIsPulling] = useState(false);
  const { user, socket } = useAuth();
  const navigate = useNavigate();
  const listRef = useRef(null);

  useEffect(() => {
    loadChats();
    loadUsers();

    if (socket) {
      socket.on('message', handleNewMessage);
      socket.on('group_message', handleNewMessage);
      socket.on('user_online', handleUserOnline);
      socket.on('friend_request', handleFriendNotification);
    }

    return () => {
      if (socket) {
        socket.off('message', handleNewMessage);
        socket.off('group_message', handleNewMessage);
        socket.off('user_online', handleUserOnline);
        socket.off('friend_request', handleFriendNotification);
      }
    };
  }, [socket]);

  const loadChats = async () => {
    try {
      const response = await axios.get('/api/chats');
      setChats(response.data);
    } catch (error) {
      console.error('Failed to load chats:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const loadUsers = async () => {
    try {
      const response = await axios.get('/api/users');
      setUsers(response.data);
    } catch (error) {
      console.error('Failed to load users:', error);
    }
  };

  const handleNewMessage = () => {
    loadChats();
  };

  const handleUserOnline = (data) => {
    setChats(prevChats =>
      prevChats.map(chat =>
        chat.type === 'private' && chat.id === data.userId
          ? { ...chat, online: data.online, lastSeen: data.lastSeen }
          : chat
      )
    );
  };

  const handleFriendNotification = (data) => {
    if (data.type === 'friend_added') {
      // 显示更明显的通知
      const notification = document.createElement('div');
      notification.className = 'fixed top-4 left-1/2 transform -translate-x-1/2 primary-bg text-white px-6 py-3 rounded-button shadow-card z-50 slide-in-right';
      notification.innerHTML = `
        <div class="flex items-center gap-2">
          <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
          </svg>
          <span>${data.message}</span>
        </div>
      `;
      document.body.appendChild(notification);
      
      setTimeout(() => {
        notification.remove();
      }, 4000);
      
      loadChats();
    }
  };

  const handleAddFriend = async (friendId) => {
    try {
      await axios.post('/api/friends/add', { friendId });
      setShowAddFriend(false);
      loadChats();
      loadUsers();
    } catch (error) {
      alert('添加好友失败');
    }
  };

  const handleCreateGroup = async () => {
    if (!groupName.trim() || selectedUsers.length === 0) {
      alert('请输入群组名称并选择至少一个成员');
      return;
    }

    try {
      await axios.post('/api/groups/create', {
        name: groupName,
        memberIds: selectedUsers
      });
      setShowCreateGroup(false);
      setGroupName('');
      setSelectedUsers([]);
      loadChats();
    } catch (error) {
      alert('创建群组失败');
    }
  };

  const formatTime = (timestamp) => {
    if (!timestamp) return '';
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now - date;

    if (diff < 60000) return '刚刚';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}分钟前`;
    if (diff < 86400000) return date.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
    return date.toLocaleDateString('zh-CN', { month: '2-digit', day: '2-digit' });
  };

  const formatLastMessage = (msg) => {
    if (!msg) return '暂无消息';
    if (msg.type === 'image') return '[图片]';
    if (msg.type === 'file') return '[文件]';
    return msg.content.length > 20 ? msg.content.substring(0, 20) + '...' : msg.content;
  };

  const getChatIcon = (chat) => {
    if (chat.type === 'group') {
      return (
        <div className="relative">
          <img
            src={chat.avatar}
            alt={chat.name}
            className="avatar"
          />
          <div className="absolute -bottom-1 -right-1 bg-blue-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center shadow-card">
            <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
              <path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z"></path>
            </svg>
          </div>
        </div>
      );
    } else {
      return (
        <div className="relative">
          <img
            src={chat.avatar}
            alt={chat.name}
            className="avatar"
          />
          {chat.online && (
            <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white breathing"></div>
          )}
        </div>
      );
    }
  };

  const getChatTypeIndicator = (chat) => {
    if (chat.type === 'group') {
      return (
        <div className="flex items-center gap-1">
          <svg className="w-4 h-4 text-blue-500" fill="currentColor" viewBox="0 0 20 20">
            <path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z"></path>
          </svg>
          <span className="text-xs text-blue-500 font-medium">群聊</span>
        </div>
      );
    } else {
      return (
        <div className="flex items-center gap-1">
          <svg className="w-4 h-4 text-green-500" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd"></path>
          </svg>
          <span className="text-xs text-green-500 font-medium">私聊</span>
        </div>
      );
    }
  };

  // 下拉刷新处理
  const handleTouchStart = (e) => {
    if (listRef.current.scrollTop === 0) {
      setStartY(e.touches[0].clientY);
      setIsPulling(true);
    }
  };

  const handleTouchMove = (e) => {
    if (isPulling && listRef.current.scrollTop === 0) {
      const currentY = e.touches[0].clientY;
      const distance = Math.max(0, currentY - startY);
      setPullDistance(Math.min(distance, 80));
    }
  };

  const handleTouchEnd = () => {
    if (isPulling && pullDistance > 50) {
      setRefreshing(true);
      loadChats();
    }
    setPullDistance(0);
    setIsPulling(false);
  };

  const EmptyState = () => (
    <div className="empty-state">
      <svg className="empty-state-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
      </svg>
      <h3 className="empty-state-title">暂无聊天记录</h3>
      <p className="empty-state-desc">点击右上角添加好友或创建群组<br/>开始您的聊天之旅</p>
    </div>
  );

  return (
    <div className="h-full flex flex-col bg-page pb-16">
      {/* Header */}
      <div className="primary-bg text-white px-4 py-3 flex items-center justify-between safe-area-pt shadow-card">
        <h1 className="text-xl font-semibold">消息</h1>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowAddFriend(true)}
            className="p-2 hover:bg-white/20 rounded-button transition-all duration-200 hover:scale-110 relative"
            title="添加好友"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
            </svg>
            {/* 添加好友提示 */}
            <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full breathing"></div>
          </button>
          <button
            onClick={() => setShowCreateGroup(true)}
            className="p-2 hover:bg-white/20 rounded-button transition-all duration-200 hover:scale-110"
            title="创建群组"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
            </svg>
          </button>
        </div>
      </div>

      {/* Chat List */}
      <div 
        ref={listRef}
        className="flex-1 overflow-y-auto scroll-smooth pull-refresh"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {/* 下拉刷新指示器 */}
        <div 
          className="pull-refresh-indicator"
          style={{ transform: `translateY(${pullDistance}px)` }}
        >
          {refreshing ? (
            <div className="flex items-center gap-2 text-tertiary">
              <div className="loading-spinner"></div>
              <span>正在更新...</span>
            </div>
          ) : pullDistance > 50 ? (
            <span className="text-tertiary">释放刷新</span>
          ) : (
            <span className="text-tertiary">下拉刷新</span>
          )}
        </div>

        {loading ? (
          <div className="flex items-center justify-center h-full">
            <div className="loading-spinner"></div>
            <span className="ml-2 text-tertiary">加载中...</span>
          </div>
        ) : chats.length === 0 ? (
          <EmptyState />
        ) : (
          <div className="p-4 space-y-2">
            {chats.map((chat, index) => (
              <div
                key={`${chat.type}-${chat.id}`}
                onClick={() => navigate(`/chat/${chat.type}/${chat.id}`)}
                className="list-item p-4 cursor-pointer slide-in"
                style={{ animationDelay: `${index * 0.05}s` }}
              >
                <div className="flex items-center gap-3">
                  {getChatIcon(chat)}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-primary truncate">{chat.name}</h3>
                        {getChatTypeIndicator(chat)}
                      </div>
                      <span className="time-relative flex-shrink-0">
                        {formatTime(chat.lastMessage?.timestamp)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <p className="text-secondary truncate">
                        {chat.lastMessage?.sender && chat.type === 'group' && (
                          <span className="text-tertiary">{chat.lastMessage.sender}: </span>
                        )}
                        {formatLastMessage(chat.lastMessage)}
                      </p>
                      {chat.unreadCount > 0 && (
                        <div className="unread-badge ml-2 flex-shrink-0">
                          {chat.unreadCount > 99 ? '99+' : chat.unreadCount}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add Friend Modal */}
      {showAddFriend && (
        <div className="modal-overlay">
          <div className="modal-content">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-primary">添加好友</h2>
              <button 
                onClick={() => setShowAddFriend(false)} 
                className="text-tertiary hover:text-primary transition-colors"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            <div className="space-y-2">
              {users.length === 0 ? (
                <p className="text-tertiary text-center py-4">没有可添加的用户</p>
              ) : (
                users.map((u) => (
                  <div key={u._id} className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-button transition-colors">
                    <div className="flex items-center gap-3">
                      <img src={u.avatar} alt={u.username} className="avatar-small" />
                      <div>
                        <p className="font-medium text-primary">{u.username}</p>
                        <p className="text-xs text-tertiary">{u.online ? '在线' : '离线'}</p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleAddFriend(u._id)}
                      className="btn-primary px-4 py-1.5 text-sm"
                    >
                      添加
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Create Group Modal */}
      {showCreateGroup && (
        <div className="modal-overlay">
          <div className="modal-content">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-primary">创建群组</h2>
              <button 
                onClick={() => setShowCreateGroup(false)} 
                className="text-tertiary hover:text-primary transition-colors"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            <input
              type="text"
              value={groupName}
              onChange={(e) => setGroupName(e.target.value)}
              placeholder="群组名称"
              className="input-field w-full mb-4"
            />
            <div className="space-y-2">
              {users.map((u) => (
                <div
                  key={u._id}
                  onClick={() => {
                    if (selectedUsers.includes(u._id)) {
                      setSelectedUsers(selectedUsers.filter(id => id !== u._id));
                    } else {
                      setSelectedUsers([...selectedUsers, u._id]);
                    }
                  }}
                  className={`flex items-center justify-between p-3 rounded-button cursor-pointer transition-all duration-200 ${
                    selectedUsers.includes(u._id) ? 'bg-green-50 scale-105' : 'hover:bg-gray-50'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <img src={u.avatar} alt={u.username} className="avatar-small" />
                    <p className="font-medium text-primary">{u.username}</p>
                  </div>
                  {selectedUsers.includes(u._id) && (
                    <svg className="w-5 h-5 primary-color" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  )}
                </div>
              ))}
            </div>
            <button
              onClick={handleCreateGroup}
              className="btn-primary w-full mt-4"
            >
              创建群组
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default MessagesPage;
