import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Sidebar from '../../components/admin/Sidebar';
import MonitoringCenter from './MonitoringCenter';
import CustomerManagement from './CustomerManagement';
import ChatAnalysis from './ChatAnalysis';
import DataInsights from './DataInsights';
import SystemConfig from './SystemConfig';
import AIAssistant from './AIAssistant';

const AdminDashboard = () => {
  const [activeModule, setActiveModule] = useState('monitoring');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const navigate = useNavigate();

  const modules = [
    { id: 'monitoring', name: '智能监控中心', icon: '📊', component: MonitoringCenter },
    { id: 'customers', name: '客户关系管理', icon: '👥', component: CustomerManagement },
    { id: 'chat-analysis', name: '对话智能分析', icon: '💬', component: ChatAnalysis },
    { id: 'data-insights', name: '数据洞察中心', icon: '📈', component: DataInsights },
    { id: 'system-config', name: '系统智能配置', icon: '⚙️', component: SystemConfig },
    { id: 'ai-assistant', name: 'AI智能助手', icon: '🤖', component: AIAssistant },
  ];

  const ActiveComponent = modules.find(m => m.id === activeModule)?.component || MonitoringCenter;

  return (
    <div className="h-screen flex bg-gray-900 text-white overflow-hidden">
      {/* Sidebar */}
      <Sidebar 
        activeModule={activeModule}
        onModuleChange={setActiveModule}
        collapsed={sidebarCollapsed}
        onToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
      />
      
      {/* Main Content */}
      <div className={`flex-1 flex flex-col transition-all duration-300 ${sidebarCollapsed ? 'ml-16' : 'ml-64'}`}>
        {/* Header */}
        <header className="bg-gray-800 border-b border-gray-700 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-2xl">🏛️</span>
            <div>
              <h1 className="text-xl font-bold">佳士得IM智能管理平台</h1>
              <p className="text-sm text-gray-400">实时监控中心</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-sm">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span>系统运行正常</span>
            </div>
            <button 
              onClick={() => navigate('/conversations')}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors"
            >
              返回前台
            </button>
          </div>
        </header>

        {/* Content Area */}
        <main className="flex-1 overflow-auto bg-gray-900">
          <ActiveComponent />
        </main>
      </div>
    </div>
  );
};

export default AdminDashboard;
