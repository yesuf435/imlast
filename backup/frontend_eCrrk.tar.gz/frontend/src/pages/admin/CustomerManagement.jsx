import React, { useState, useEffect } from 'react';
import axios from 'axios';

const CustomerManagement = () => {
  const [customers, setCustomers] = useState([]);
  const [filteredCustomers, setFilteredCustomers] = useState([]);
  const [selectedFilter, setSelectedFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadCustomers();
  }, []);

  useEffect(() => {
    filterCustomers();
  }, [customers, selectedFilter, searchTerm]);

  const loadCustomers = async () => {
    try {
      // 模拟客户数据
      const mockCustomers = [
        {
          id: 'CS001',
          name: '王先生',
          advisor: '张明',
          lastActive: '刚刚',
          level: 'vip',
          value: 4.8,
          totalTransactions: 156,
          totalAmount: 2850000,
          joinDate: '2023-01-15',
          avatar: 'https://ui-avatars.com/api/?background=0A1E3A&color=fff&name=王'
        },
        {
          id: 'CS002',
          name: '李女士',
          advisor: '李静',
          lastActive: '2小时前',
          level: 'premium',
          value: 4.5,
          totalTransactions: 89,
          totalAmount: 1200000,
          joinDate: '2023-03-22',
          avatar: 'https://ui-avatars.com/api/?background=C4A86F&color=fff&name=李'
        },
        {
          id: 'CS003',
          name: '陈总',
          advisor: '陈华',
          lastActive: '昨天',
          level: 'vip',
          value: 4.9,
          totalTransactions: 234,
          totalAmount: 4500000,
          joinDate: '2022-11-08',
          avatar: 'https://ui-avatars.com/api/?background=0A1E3A&color=fff&name=陈'
        },
        {
          id: 'CS004',
          name: '刘女士',
          advisor: '张明',
          lastActive: '3天前',
          level: 'standard',
          value: 4.2,
          totalTransactions: 45,
          totalAmount: 680000,
          joinDate: '2023-06-10',
          avatar: 'https://ui-avatars.com/api/?background=C4A86F&color=fff&name=刘'
        }
      ];
      setCustomers(mockCustomers);
    } catch (error) {
      console.error('Failed to load customers:', error);
    } finally {
      setLoading(false);
    }
  };

  const filterCustomers = () => {
    let filtered = customers;

    // 按客户等级筛选
    if (selectedFilter !== 'all') {
      filtered = filtered.filter(customer => customer.level === selectedFilter);
    }

    // 按搜索词筛选
    if (searchTerm) {
      filtered = filtered.filter(customer => 
        customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        customer.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        customer.advisor.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    setFilteredCustomers(filtered);
  };

  const getLevelBadge = (level) => {
    switch (level) {
      case 'vip':
        return <span className="px-2 py-1 bg-gradient-to-r from-yellow-500 to-orange-500 text-white text-xs rounded-full">🌟 VIP</span>;
      case 'premium':
        return <span className="px-2 py-1 bg-gradient-to-r from-blue-500 to-purple-500 text-white text-xs rounded-full">⭐ 尊贵</span>;
      case 'standard':
        return <span className="px-2 py-1 bg-gray-500 text-white text-xs rounded-full">👤 标准</span>;
      default:
        return <span className="px-2 py-1 bg-gray-500 text-white text-xs rounded-full">👤 标准</span>;
    }
  };

  const getValueStars = (value) => {
    const stars = [];
    const fullStars = Math.floor(value);
    const hasHalfStar = value % 1 >= 0.5;

    for (let i = 0; i < fullStars; i++) {
      stars.push(<span key={i} className="text-yellow-400">⭐</span>);
    }
    if (hasHalfStar) {
      stars.push(<span key="half" className="text-yellow-400">⭐</span>);
    }
    const emptyStars = 5 - Math.ceil(value);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<span key={`empty-${i}`} className="text-gray-500">☆</span>);
    }
    return stars;
  };

  const formatAmount = (amount) => {
    return new Intl.NumberFormat('zh-CN', {
      style: 'currency',
      currency: 'CNY',
      minimumFractionDigits: 0
    }).format(amount);
  };

  const CustomerCard = ({ customer }) => (
    <div className="bg-gray-800 rounded-lg p-6 border border-gray-700 hover:border-blue-500 transition-colors cursor-pointer"
         onClick={() => setSelectedCustomer(customer)}>
      <div className="flex items-start gap-4">
        <img 
          src={customer.avatar} 
          alt={customer.name}
          className="w-16 h-16 rounded-full border-2 border-gray-600"
        />
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            <h3 className="text-lg font-semibold text-white">{customer.name}</h3>
            {getLevelBadge(customer.level)}
          </div>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-gray-400">专属顾问</p>
              <p className="text-white">{customer.advisor}</p>
            </div>
            <div>
              <p className="text-gray-400">最后活跃</p>
              <p className="text-white">{customer.lastActive}</p>
            </div>
            <div>
              <p className="text-gray-400">交易总额</p>
              <p className="text-green-400 font-semibold">{formatAmount(customer.totalAmount)}</p>
            </div>
            <div>
              <p className="text-gray-400">价值评级</p>
              <div className="flex items-center gap-1">
                {getValueStars(customer.value)}
                <span className="text-white ml-1">{customer.value}</span>
              </div>
            </div>
          </div>
        </div>
        <div className="flex flex-col gap-2">
          <button className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded transition-colors">
            详情
          </button>
          <button className="px-3 py-1 bg-green-600 hover:bg-green-700 text-white text-sm rounded transition-colors">
            对话
          </button>
        </div>
      </div>
    </div>
  );

  const CustomerDetailModal = ({ customer, onClose }) => {
    if (!customer) return null;

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-gray-800 rounded-lg p-6 w-full max-w-2xl mx-4 border border-gray-700">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-white">客户详情</h2>
            <button onClick={onClose} className="text-gray-400 hover:text-white">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-semibold text-white mb-4">基本信息</h3>
              <div className="space-y-3">
                <div>
                  <span className="text-gray-400">客户ID:</span>
                  <span className="text-white ml-2">{customer.id}</span>
                </div>
                <div>
                  <span className="text-gray-400">客户姓名:</span>
                  <span className="text-white ml-2">{customer.name}</span>
                </div>
                <div>
                  <span className="text-gray-400">专属顾问:</span>
                  <span className="text-white ml-2">{customer.advisor}</span>
                </div>
                <div>
                  <span className="text-gray-400">加入时间:</span>
                  <span className="text-white ml-2">{customer.joinDate}</span>
                </div>
                <div>
                  <span className="text-gray-400">客户等级:</span>
                  <span className="ml-2">{getLevelBadge(customer.level)}</span>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold text-white mb-4">交易统计</h3>
              <div className="space-y-3">
                <div>
                  <span className="text-gray-400">交易次数:</span>
                  <span className="text-white ml-2">{customer.totalTransactions}次</span>
                </div>
                <div>
                  <span className="text-gray-400">交易总额:</span>
                  <span className="text-green-400 ml-2 font-semibold">{formatAmount(customer.totalAmount)}</span>
                </div>
                <div>
                  <span className="text-gray-400">平均交易:</span>
                  <span className="text-white ml-2">{formatAmount(customer.totalAmount / customer.totalTransactions)}</span>
                </div>
                <div>
                  <span className="text-gray-400">价值评级:</span>
                  <div className="flex items-center gap-1 ml-2">
                    {getValueStars(customer.value)}
                    <span className="text-white ml-1">{customer.value}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-6 flex gap-3">
            <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded transition-colors">
              查看对话记录
            </button>
            <button className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded transition-colors">
              发送消息
            </button>
            <button className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded transition-colors">
              修改头衔
            </button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">客户关系管理</h1>
          <p className="text-gray-400">多维度客户视图 · 客户价值分析</p>
        </div>
        <div className="flex items-center gap-4">
          <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors">
            导出客户数据
          </button>
          <button className="px-4 py-2 bg-green-600 hover:bg-green-700 rounded-lg transition-colors">
            添加新客户
          </button>
        </div>
      </div>

      {/* Advanced Filters */}
      <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4">🔍 高级筛选</h3>
        <div className="flex flex-wrap gap-4">
          <div className="flex gap-2">
            <button
              onClick={() => setSelectedFilter('all')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                selectedFilter === 'all' ? 'bg-blue-600 text-white' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              }`}
            >
              所有客户
            </button>
            <button
              onClick={() => setSelectedFilter('vip')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                selectedFilter === 'vip' ? 'bg-blue-600 text-white' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              }`}
            >
              VIP客户
            </button>
            <button
              onClick={() => setSelectedFilter('premium')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                selectedFilter === 'premium' ? 'bg-blue-600 text-white' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              }`}
            >
              重要藏家
            </button>
            <button
              onClick={() => setSelectedFilter('standard')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                selectedFilter === 'standard' ? 'bg-blue-600 text-white' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              }`}
            >
              新客户
            </button>
          </div>
          <div className="flex-1 max-w-md">
            <input
              type="text"
              placeholder="搜索客户名称、ID或顾问..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:border-blue-500 focus:outline-none"
            />
          </div>
        </div>
      </div>

      {/* Customer Analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <h3 className="text-lg font-semibold text-white mb-4">客户画像分析</h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-gray-400">VIP客户</span>
              <div className="flex items-center gap-2">
                <div className="w-20 bg-gray-700 rounded-full h-2">
                  <div className="bg-gradient-to-r from-yellow-500 to-orange-500 h-2 rounded-full" style={{width: '25%'}}></div>
                </div>
                <span className="text-white">25%</span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400">尊贵客户</span>
              <div className="flex items-center gap-2">
                <div className="w-20 bg-gray-700 rounded-full h-2">
                  <div className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full" style={{width: '35%'}}></div>
                </div>
                <span className="text-white">35%</span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400">标准客户</span>
              <div className="flex items-center gap-2">
                <div className="w-20 bg-gray-700 rounded-full h-2">
                  <div className="bg-gray-500 h-2 rounded-full" style={{width: '40%'}}></div>
                </div>
                <span className="text-white">40%</span>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <h3 className="text-lg font-semibold text-white mb-4">服务轨迹追踪</h3>
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span className="text-sm text-gray-300">咨询阶段</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              <span className="text-sm text-gray-300">评估阶段</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
              <span className="text-sm text-gray-300">交易阶段</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
              <span className="text-sm text-gray-300">维护阶段</span>
            </div>
          </div>
        </div>

        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <h3 className="text-lg font-semibold text-white mb-4">价值评级系统</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-gray-400">平均评分</span>
              <div className="flex items-center gap-1">
                {getValueStars(4.6)}
                <span className="text-white ml-1">4.6</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-400">满意度</span>
              <span className="text-green-400">92%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-400">复购率</span>
              <span className="text-blue-400">78%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Customer List */}
      <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-white">📋 客户列表 ({filteredCustomers.length})</h3>
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-400">排序:</span>
            <select className="px-3 py-1 bg-gray-700 border border-gray-600 rounded text-white text-sm">
              <option>按价值评级</option>
              <option>按交易总额</option>
              <option>按最后活跃</option>
              <option>按加入时间</option>
            </select>
          </div>
        </div>
        
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
            <span className="ml-3 text-gray-400">加载中...</span>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {filteredCustomers.map((customer) => (
              <CustomerCard key={customer.id} customer={customer} />
            ))}
          </div>
        )}
      </div>

      {/* Customer Detail Modal */}
      <CustomerDetailModal 
        customer={selectedCustomer} 
        onClose={() => setSelectedCustomer(null)} 
      />
    </div>
  );
};

export default CustomerManagement;
