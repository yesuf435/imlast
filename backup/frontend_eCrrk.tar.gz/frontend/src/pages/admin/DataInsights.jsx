import React, { useState } from 'react';

const DataInsights = () => {
  const [timeRange, setTimeRange] = useState('today');
  const [selectedReports, setSelectedReports] = useState([]);

  const reports = [
    { id: 'customer-behavior', name: '客户行为分析报表', icon: '👥' },
    { id: 'advisor-performance', name: '顾问绩效报表', icon: '📊' },
    { id: 'service-quality', name: '服务质量分析报表', icon: '⭐' },
    { id: 'business-insights', name: '业务洞察报表', icon: '💡' }
  ];

  const toggleReport = (reportId) => {
    setSelectedReports(prev => 
      prev.includes(reportId) 
        ? prev.filter(id => id !== reportId)
        : [...prev, reportId]
    );
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">数据洞察中心</h1>
          <p className="text-gray-400">高级分析报表 · 业务数据可视化</p>
        </div>
      </div>

      <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4">📅 时间维度分析</h3>
        <div className="flex gap-4 mb-6">
          {['今日', '本周', '本月', '自定义'].map((range) => (
            <button
              key={range}
              onClick={() => setTimeRange(range.toLowerCase())}
              className={`px-4 py-2 rounded-lg transition-colors ${
                timeRange === range.toLowerCase() ? 'bg-blue-600 text-white' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              }`}
            >
              {range}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="bg-gray-700 rounded-lg p-4">
            <h4 className="text-md font-medium text-white mb-3">用户活跃度分析</h4>
            <div className="text-6xl text-center">📊📈➡️📉</div>
          </div>
          <div className="bg-gray-700 rounded-lg p-4">
            <h4 className="text-md font-medium text-white mb-3">服务峰值分布</h4>
            <div className="text-6xl text-center">🏔️⛰️🏔️</div>
          </div>
          <div className="bg-gray-700 rounded-lg p-4">
            <h4 className="text-md font-medium text-white mb-3">业务转化漏斗</h4>
            <div className="text-6xl text-center">🔻🔻🔻</div>
          </div>
        </div>
      </div>

      <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4">📋 高级报表生成器</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {reports.map((report) => (
            <div
              key={report.id}
              onClick={() => toggleReport(report.id)}
              className={`p-4 rounded-lg border cursor-pointer transition-colors ${
                selectedReports.includes(report.id)
                  ? 'bg-blue-600 border-blue-500 text-white'
                  : 'bg-gray-700 border-gray-600 text-gray-300 hover:bg-gray-600'
              }`}
            >
              <div className="flex items-center gap-3">
                <span className="text-2xl">{report.icon}</span>
                <span className="font-medium">{report.name}</span>
              </div>
            </div>
          ))}
        </div>
        <div className="flex gap-4">
          <button className="px-6 py-2 bg-green-600 hover:bg-green-700 rounded-lg transition-colors">
            立即生成
          </button>
          <button className="px-6 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors">
            定时发送
          </button>
          <button className="px-6 py-2 bg-purple-600 hover:bg-purple-700 rounded-lg transition-colors">
            导出Excel
          </button>
          <button className="px-6 py-2 bg-orange-600 hover:bg-orange-700 rounded-lg transition-colors">
            数据可视化
          </button>
        </div>
      </div>
    </div>
  );
};

export default DataInsights;
