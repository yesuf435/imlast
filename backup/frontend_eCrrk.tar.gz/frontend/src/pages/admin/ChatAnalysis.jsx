import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ChatAnalysis = () => {
  const [chatMetrics, setChatMetrics] = useState({
    satisfaction: 92,
    responseRate: 98,
    resolutionRate: 89,
    avgDuration: 8.7,
    keywords: 256
  });

  const [sentimentTrend, setSentimentTrend] = useState([
    { time: '09:00', sentiment: 0.8 },
    { time: '10:00', sentiment: 0.6 },
    { time: '11:00', sentiment: 0.9 },
    { time: '12:00', sentiment: 0.7 },
    { time: '13:00', sentiment: 0.8 },
    { time: '14:00', sentiment: 0.9 },
    { time: '15:00', sentiment: 0.8 },
    { time: '16:00', sentiment: 0.9 }
  ]);

  const [topicHeatmap, setTopicHeatmap] = useState([
    { topic: '艺术品鉴定', heat: 85 },
    { topic: '拍卖咨询', heat: 78 },
    { topic: '价格评估', heat: 92 },
    { topic: '收藏建议', heat: 65 },
    { topic: '市场趋势', heat: 88 },
    { topic: '投资建议', heat: 73 }
  ]);

  const [serviceEfficiency, setServiceEfficiency] = useState([
    { advisor: '张明', efficiency: 95, satisfaction: 4.8, responseTime: 45 },
    { advisor: '李静', efficiency: 88, satisfaction: 4.6, responseTime: 52 },
    { advisor: '陈华', efficiency: 92, satisfaction: 4.7, responseTime: 48 },
    { advisor: '王丽', efficiency: 85, satisfaction: 4.5, responseTime: 58 }
  ]);

  const [chatRecords, setChatRecords] = useState([
    {
      id: 1,
      customer: '王先生',
      advisor: '张明',
      topic: '艺术品鉴定',
      sentiment: 'positive',
      duration: 12.5,
      messages: 24,
      satisfaction: 5,
      timestamp: '2025-01-11 14:30'
    },
    {
      id: 2,
      customer: '李女士',
      advisor: '李静',
      topic: '拍卖咨询',
      sentiment: 'positive',
      duration: 8.2,
      messages: 16,
      satisfaction: 4,
      timestamp: '2025-01-11 13:45'
    },
    {
      id: 3,
      customer: '陈总',
      advisor: '陈华',
      topic: '价格评估',
      sentiment: 'neutral',
      duration: 15.8,
      messages: 31,
      satisfaction: 4,
      timestamp: '2025-01-11 12:20'
    }
  ]);

  const [searchFilters, setSearchFilters] = useState({
    keyword: '',
    timeRange: 'today',
    advisor: '',
    customer: ''
  });

  const MetricCard = ({ title, value, unit, trend, icon }) => (
    <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-medium text-gray-400">{title}</h3>
        <span className="text-2xl">{icon}</span>
      </div>
      <div className="flex items-baseline gap-2">
        <span className="text-3xl font-bold text-white">{value}</span>
        <span className="text-sm text-gray-400">{unit}</span>
        {trend && (
          <span className={`text-xs px-2 py-1 rounded ${
            trend > 0 ? 'bg-green-900 text-green-300' : 'bg-red-900 text-red-300'
          }`}>
            {trend > 0 ? '+' : ''}{trend}%
          </span>
        )}
      </div>
    </div>
  );

  const SentimentChart = () => (
    <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
      <h3 className="text-lg font-semibold text-white mb-4">情感分析趋势</h3>
      <div className="space-y-3">
        {sentimentTrend.map((point, index) => (
          <div key={index} className="flex items-center gap-3">
            <span className="text-sm text-gray-400 w-12">{point.time}</span>
            <div className="flex-1 bg-gray-700 rounded-full h-2">
              <div 
                className={`h-2 rounded-full transition-all duration-500 ${
                  point.sentiment > 0.7 ? 'bg-green-500' : 
                  point.sentiment > 0.4 ? 'bg-yellow-500' : 'bg-red-500'
                }`}
                style={{ width: `${point.sentiment * 100}%` }}
              />
            </div>
            <span className="text-sm text-white w-8">{Math.round(point.sentiment * 100)}%</span>
          </div>
        ))}
      </div>
    </div>
  );

  const TopicHeatmapChart = () => (
    <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
      <h3 className="text-lg font-semibold text-white mb-4">话题热度分布</h3>
      <div className="space-y-3">
        {topicHeatmap.map((topic, index) => (
          <div key={index} className="flex items-center gap-3">
            <span className="text-sm text-gray-400 w-20">{topic.topic}</span>
            <div className="flex-1 bg-gray-700 rounded-full h-2">
              <div 
                className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full transition-all duration-500"
                style={{ width: `${topic.heat}%` }}
              />
            </div>
            <span className="text-sm text-white w-8">{topic.heat}%</span>
          </div>
        ))}
      </div>
    </div>
  );

  const ServiceEfficiencyMatrix = () => (
    <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
      <h3 className="text-lg font-semibold text-white mb-4">服务效率矩阵</h3>
      <div className="space-y-4">
        {serviceEfficiency.map((advisor, index) => (
          <div key={index} className="flex items-center gap-4">
            <div className="w-16 text-sm text-gray-300">{advisor.advisor}</div>
            <div className="flex-1 grid grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-lg font-semibold text-white">{advisor.efficiency}%</div>
                <div className="text-xs text-gray-400">效率</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-semibold text-yellow-400">{advisor.satisfaction}</div>
                <div className="text-xs text-gray-400">满意度</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-semibold text-blue-400">{advisor.responseTime}s</div>
                <div className="text-xs text-gray-400">响应时间</div>
              </div>
            </div>
            <div className="w-20">
              <div className={`w-full h-2 rounded-full ${
                advisor.efficiency > 90 ? 'bg-green-500' :
                advisor.efficiency > 80 ? 'bg-yellow-500' : 'bg-red-500'
              }`} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const ChatRecordRow = ({ record }) => (
    <div className="bg-gray-700 rounded-lg p-4 hover:bg-gray-600 transition-colors cursor-pointer">
      <div className="grid grid-cols-6 gap-4 items-center">
        <div>
          <div className="text-sm font-medium text-white">{record.customer}</div>
          <div className="text-xs text-gray-400">{record.advisor}</div>
        </div>
        <div className="text-sm text-gray-300">{record.topic}</div>
        <div className="flex items-center gap-1">
          <span className={`text-lg ${
            record.sentiment === 'positive' ? 'text-green-400' :
            record.sentiment === 'neutral' ? 'text-yellow-400' : 'text-red-400'
          }`}>
            {record.sentiment === 'positive' ? '😊' : 
             record.sentiment === 'neutral' ? '😐' : '😞'}
          </span>
        </div>
        <div className="text-sm text-gray-300">{record.duration}分钟</div>
        <div className="flex items-center gap-1">
          {Array.from({ length: 5 }, (_, i) => (
            <span key={i} className={`text-sm ${
              i < record.satisfaction ? 'text-yellow-400' : 'text-gray-500'
            }`}>⭐</span>
          ))}
        </div>
        <div className="text-sm text-gray-400">{record.timestamp}</div>
      </div>
    </div>
  );

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">对话智能分析中心</h1>
          <p className="text-gray-400">深度对话洞察 · 服务质量分析</p>
        </div>
        <div className="flex items-center gap-4">
          <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors">
            导出分析报告
          </button>
          <button className="px-4 py-2 bg-green-600 hover:bg-green-700 rounded-lg transition-colors">
            实时分析
          </button>
        </div>
      </div>

      {/* Chat Quality Analysis */}
      <div>
        <h2 className="text-lg font-semibold text-white mb-4">🎯 对话质量分析</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          <MetricCard 
            title="满意度" 
            value={chatMetrics.satisfaction} 
            unit="%" 
            trend={3.2}
            icon="😊"
          />
          <MetricCard 
            title="响应率" 
            value={chatMetrics.responseRate} 
            unit="%" 
            trend={1.5}
            icon="⚡"
          />
          <MetricCard 
            title="解决率" 
            value={chatMetrics.resolutionRate} 
            unit="%" 
            trend={2.8}
            icon="✅"
          />
          <MetricCard 
            title="对话时长" 
            value={chatMetrics.avgDuration} 
            unit="分钟" 
            trend={-1.2}
            icon="⏱️"
          />
          <MetricCard 
            title="关键词" 
            value={chatMetrics.keywords} 
            unit="个" 
            trend={5.6}
            icon="🔍"
          />
        </div>
      </div>

      {/* Multi-dimensional Analysis Tools */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <SentimentChart />
        <TopicHeatmapChart />
        <ServiceEfficiencyMatrix />
      </div>

      {/* Chat Record Search */}
      <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4">🔍 对话记录搜索</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <input
            type="text"
            placeholder="关键词搜索..."
            value={searchFilters.keyword}
            onChange={(e) => setSearchFilters({...searchFilters, keyword: e.target.value})}
            className="px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:border-blue-500 focus:outline-none"
          />
          <select
            value={searchFilters.timeRange}
            onChange={(e) => setSearchFilters({...searchFilters, timeRange: e.target.value})}
            className="px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
          >
            <option value="today">今天</option>
            <option value="week">本周</option>
            <option value="month">本月</option>
            <option value="custom">自定义</option>
          </select>
          <select
            value={searchFilters.advisor}
            onChange={(e) => setSearchFilters({...searchFilters, advisor: e.target.value})}
            className="px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
          >
            <option value="">所有顾问</option>
            <option value="张明">张明</option>
            <option value="李静">李静</option>
            <option value="陈华">陈华</option>
            <option value="王丽">王丽</option>
          </select>
          <input
            type="text"
            placeholder="客户名称..."
            value={searchFilters.customer}
            onChange={(e) => setSearchFilters({...searchFilters, customer: e.target.value})}
            className="px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:border-blue-500 focus:outline-none"
          />
        </div>

        <div className="space-y-2">
          <div className="grid grid-cols-6 gap-4 text-sm text-gray-400 font-medium pb-2 border-b border-gray-600">
            <div>客户/顾问</div>
            <div>话题</div>
            <div>情感</div>
            <div>时长</div>
            <div>满意度</div>
            <div>时间</div>
          </div>
          {chatRecords.map((record) => (
            <ChatRecordRow key={record.id} record={record} />
          ))}
        </div>
      </div>

      {/* AI Insights */}
      <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4">🤖 AI智能洞察</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h4 className="text-md font-medium text-white mb-3">关键发现</h4>
            <ul className="space-y-2 text-sm text-gray-300">
              <li>• 艺术品鉴定话题满意度最高，达到95%</li>
              <li>• 张明顾问在价格评估方面表现突出</li>
              <li>• 下午2-4点是客户咨询高峰期</li>
              <li>• VIP客户平均对话时长比普通客户长40%</li>
            </ul>
          </div>
          <div>
            <h4 className="text-md font-medium text-white mb-3">优化建议</h4>
            <ul className="space-y-2 text-sm text-gray-300">
              <li>• 建议增加艺术品鉴定专业顾问</li>
              <li>• 优化价格评估流程，提升响应速度</li>
              <li>• 在高峰期增加在线顾问数量</li>
              <li>• 为VIP客户提供专属快速通道</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatAnalysis;
