import React, { useState, useEffect } from 'react';
import axios from 'axios';

const MonitoringCenter = () => {
  const [metrics, setMetrics] = useState({
    onlineCustomers: 1248,
    activeAdvisors: 586,
    messageThroughput: 3245,
    responseTime: 87,
    serviceRating: 4.8
  });

  const [alerts, setAlerts] = useState([
    { id: 1, type: 'warning', message: '客户等待超时预警 (3条)', time: '2分钟前' },
    { id: 2, type: 'warning', message: '顾问响应延迟预警 (7条)', time: '5分钟前' },
    { id: 3, type: 'success', message: '系统运行正常', time: '刚刚' }
  ]);

  const [messageHeatmap, setMessageHeatmap] = useState([
    [8, 12, 15, 18, 22, 16, 10],
    [6, 10, 14, 20, 25, 19, 12],
    [4, 8, 12, 16, 21, 17, 9],
    [2, 6, 10, 14, 18, 15, 7]
  ]);

  const [servicePressure, setServicePressure] = useState([
    { department: '珠宝部', pressure: 85, advisors: 12 },
    { department: '书画部', pressure: 72, advisors: 8 },
    { department: '古董部', pressure: 68, advisors: 10 },
    { department: '现代艺术部', pressure: 45, advisors: 6 }
  ]);

  useEffect(() => {
    // 模拟实时数据更新
    const interval = setInterval(() => {
      setMetrics(prev => ({
        ...prev,
        onlineCustomers: prev.onlineCustomers + Math.floor(Math.random() * 10 - 5),
        messageThroughput: prev.messageThroughput + Math.floor(Math.random() * 20 - 10),
        responseTime: Math.max(30, prev.responseTime + Math.floor(Math.random() * 10 - 5))
      }));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const MetricCard = ({ title, value, unit, trend, icon }) => (
    <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-medium text-gray-400">{title}</h3>
        <span className="text-2xl">{icon}</span>
      </div>
      <div className="flex items-baseline gap-2">
        <span className="text-3xl font-bold text-white">{value}</span>
        <span className="text-sm text-gray-400">{unit}</span>
        {trend && (
          <span className={`text-xs px-2 py-1 rounded ${
            trend > 0 ? 'bg-green-900 text-green-300' : 'bg-red-900 text-red-300'
          }`}>
            {trend > 0 ? '+' : ''}{trend}%
          </span>
        )}
      </div>
    </div>
  );

  const HeatmapCell = ({ intensity }) => {
    const opacity = intensity / 25;
    return (
      <div 
        className="w-8 h-8 rounded border border-gray-600"
        style={{ backgroundColor: `rgba(59, 130, 246, ${opacity})` }}
      />
    );
  };

  const PressureBar = ({ department, pressure, advisors }) => (
    <div className="flex items-center gap-3">
      <span className="w-20 text-sm text-gray-300">{department}</span>
      <div className="flex-1 bg-gray-700 rounded-full h-2">
        <div 
          className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full transition-all duration-500"
          style={{ width: `${pressure}%` }}
        />
      </div>
      <span className="text-sm text-gray-400">{pressure}%</span>
      <span className="text-xs text-gray-500">({advisors}人)</span>
    </div>
  );

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">智能监控中心</h1>
          <p className="text-gray-400">实时数据大屏 · 系统运行状态监控</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-sm">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-gray-300">实时更新</span>
          </div>
          <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors">
            刷新数据
          </button>
        </div>
      </div>

      {/* Core Metrics */}
      <div>
        <h2 className="text-lg font-semibold text-white mb-4">📊 核心指标实时监控</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          <MetricCard 
            title="在线客户" 
            value={metrics.onlineCustomers} 
            unit="人" 
            trend={2.3}
            icon="👥"
          />
          <MetricCard 
            title="活跃顾问" 
            value={metrics.activeAdvisors} 
            unit="人" 
            trend={-1.2}
            icon="👨‍💼"
          />
          <MetricCard 
            title="消息吞吐" 
            value={metrics.messageThroughput} 
            unit="条/时" 
            trend={5.7}
            icon="💬"
          />
          <MetricCard 
            title="响应时效" 
            value={metrics.responseTime} 
            unit="秒" 
            trend={-3.1}
            icon="⏱️"
          />
          <MetricCard 
            title="服务评分" 
            value={metrics.serviceRating} 
            unit="🌟" 
            trend={0.8}
            icon="⭐"
          />
        </div>
      </div>

      {/* Real-time Data Flow */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <h3 className="text-lg font-semibold text-white mb-4">📈 实时数据流监控</h3>
          <div className="space-y-4">
            <div>
              <h4 className="text-sm text-gray-400 mb-2">消息热力图</h4>
              <div className="space-y-1">
                {messageHeatmap.map((row, rowIndex) => (
                  <div key={rowIndex} className="flex gap-1">
                    {row.map((intensity, colIndex) => (
                      <HeatmapCell key={colIndex} intensity={intensity} />
                    ))}
                  </div>
                ))}
              </div>
              <div className="flex justify-between text-xs text-gray-500 mt-2">
                <span>周一</span>
                <span>周日</span>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <h3 className="text-lg font-semibold text-white mb-4">📊 服务压力分布</h3>
          <div className="space-y-4">
            {servicePressure.map((dept, index) => (
              <PressureBar 
                key={index}
                department={dept.department}
                pressure={dept.pressure}
                advisors={dept.advisors}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Smart Alert Center */}
      <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4">🔔 智能预警中心</h3>
        <div className="space-y-3">
          {alerts.map((alert) => (
            <div 
              key={alert.id}
              className={`flex items-center gap-3 p-3 rounded-lg ${
                alert.type === 'warning' ? 'bg-yellow-900/20 border border-yellow-700' :
                alert.type === 'success' ? 'bg-green-900/20 border border-green-700' :
                'bg-gray-700'
              }`}
            >
              <span className={`text-lg ${
                alert.type === 'warning' ? 'text-yellow-400' :
                alert.type === 'success' ? 'text-green-400' :
                'text-gray-400'
              }`}>
                {alert.type === 'warning' ? '⚠️' : '✅'}
              </span>
              <div className="flex-1">
                <p className="text-white">{alert.message}</p>
                <p className="text-xs text-gray-400">{alert.time}</p>
              </div>
              <button className="text-gray-400 hover:text-white transition-colors">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4">⚡ 快速操作</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <button className="p-4 bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors">
            <div className="text-2xl mb-2">📊</div>
            <div className="text-sm">生成报表</div>
          </button>
          <button className="p-4 bg-green-600 hover:bg-green-700 rounded-lg transition-colors">
            <div className="text-2xl mb-2">🔔</div>
            <div className="text-sm">发送通知</div>
          </button>
          <button className="p-4 bg-purple-600 hover:bg-purple-700 rounded-lg transition-colors">
            <div className="text-2xl mb-2">⚙️</div>
            <div className="text-sm">系统配置</div>
          </button>
          <button className="p-4 bg-orange-600 hover:bg-orange-700 rounded-lg transition-colors">
            <div className="text-2xl mb-2">🤖</div>
            <div className="text-sm">AI助手</div>
          </button>
        </div>
      </div>
    </div>
  );
};

export default MonitoringCenter;
