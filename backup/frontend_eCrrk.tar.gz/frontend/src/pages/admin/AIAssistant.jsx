import React, { useState } from 'react';

const AIAssistant = () => {
  const [aiModules, setAiModules] = useState({
    smartService: { enabled: true, accuracy: 92 },
    emotionAnalysis: { enabled: true, accuracy: 88 },
    autoTagging: { enabled: false, accuracy: 76 }
  });

  const toggleModule = (module) => {
    setAiModules(prev => ({
      ...prev,
      [module]: { ...prev[module], enabled: !prev[module].enabled }
    }));
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">AI智能助手实验室</h1>
          <p className="text-gray-400">未来科技感 · 智能功能模块</p>
        </div>
      </div>

      <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4">🧠 智能功能模块</h3>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="bg-gray-700 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-md font-medium text-white">智能客服助手</h4>
              <button
                onClick={() => toggleModule('smartService')}
                className={`px-3 py-1 rounded text-sm ${
                  aiModules.smartService.enabled ? 'bg-green-600 text-white' : 'bg-gray-600 text-gray-300'
                }`}
              >
                {aiModules.smartService.enabled ? '已启用' : '已禁用'}
              </button>
            </div>
            <div className="text-sm text-gray-400 mb-2">准确率: {aiModules.smartService.accuracy}%</div>
            <div className="w-full bg-gray-600 rounded-full h-2">
              <div 
                className="bg-green-500 h-2 rounded-full transition-all duration-500"
                style={{ width: `${aiModules.smartService.accuracy}%` }}
              />
            </div>
          </div>

          <div className="bg-gray-700 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-md font-medium text-white">对话情感分析</h4>
              <button
                onClick={() => toggleModule('emotionAnalysis')}
                className={`px-3 py-1 rounded text-sm ${
                  aiModules.emotionAnalysis.enabled ? 'bg-green-600 text-white' : 'bg-gray-600 text-gray-300'
                }`}
              >
                {aiModules.emotionAnalysis.enabled ? '已启用' : '已禁用'}
              </button>
            </div>
            <div className="text-sm text-gray-400 mb-2">准确率: {aiModules.emotionAnalysis.accuracy}%</div>
            <div className="w-full bg-gray-600 rounded-full h-2">
              <div 
                className="bg-blue-500 h-2 rounded-full transition-all duration-500"
                style={{ width: `${aiModules.emotionAnalysis.accuracy}%` }}
              />
            </div>
          </div>

          <div className="bg-gray-700 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-md font-medium text-white">自动标签生成</h4>
              <button
                onClick={() => toggleModule('autoTagging')}
                className={`px-3 py-1 rounded text-sm ${
                  aiModules.autoTagging.enabled ? 'bg-green-600 text-white' : 'bg-yellow-600 text-white'
                }`}
              >
                {aiModules.autoTagging.enabled ? '已启用' : '测试中'}
              </button>
            </div>
            <div className="text-sm text-gray-400 mb-2">准确率: {aiModules.autoTagging.accuracy}%</div>
            <div className="w-full bg-gray-600 rounded-full h-2">
              <div 
                className="bg-yellow-500 h-2 rounded-full transition-all duration-500"
                style={{ width: `${aiModules.autoTagging.accuracy}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4">💡 智能建议与预测</h3>
        <div className="space-y-4">
          <div className="bg-gray-700 rounded-lg p-4">
            <h4 className="text-md font-medium text-white mb-3">🔮 基于历史数据预测：</h4>
            <ul className="space-y-2 text-sm text-gray-300">
              <li>• 明日活跃客户数：约 1,350人 (+8%)</li>
              <li>• 建议增加2名顾问应对高峰时段</li>
              <li>• 检测到3个潜在VIP客户需重点关注</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AIAssistant;
