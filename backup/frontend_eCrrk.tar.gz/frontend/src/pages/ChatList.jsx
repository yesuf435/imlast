import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';

const ChatList = () => {
  const [chats, setChats] = useState([]);
  const [users, setUsers] = useState([]);
  const [showAddFriend, setShowAddFriend] = useState(false);
  const [showCreateGroup, setShowCreateGroup] = useState(false);
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [groupName, setGroupName] = useState('');
  const [loading, setLoading] = useState(true);
  const { user, logout, socket } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    loadChats();
    loadUsers();

    if (socket) {
      socket.on('message', handleNewMessage);
      socket.on('group_message', handleNewMessage);
      socket.on('user_online', handleUserOnline);
    }

    return () => {
      if (socket) {
        socket.off('message', handleNewMessage);
        socket.off('group_message', handleNewMessage);
        socket.off('user_online', handleUserOnline);
      }
    };
  }, [socket]);

  const loadChats = async () => {
    try {
      const response = await axios.get('/api/chats');
      setChats(response.data);
    } catch (error) {
      console.error('Failed to load chats:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadUsers = async () => {
    try {
      const response = await axios.get('/api/users');
      setUsers(response.data);
    } catch (error) {
      console.error('Failed to load users:', error);
    }
  };

  const handleNewMessage = () => {
    loadChats();
  };

  const handleUserOnline = (data) => {
    setChats(prevChats =>
      prevChats.map(chat =>
        chat.type === 'private' && chat.id === data.userId
          ? { ...chat, online: data.online, lastSeen: data.lastSeen }
          : chat
      )
    );
  };

  const handleAddFriend = async (friendId) => {
    try {
      await axios.post('/api/friends/add', { friendId });
      setShowAddFriend(false);
      loadChats();
      loadUsers();
    } catch (error) {
      alert('添加好友失败');
    }
  };

  const handleCreateGroup = async () => {
    if (!groupName.trim() || selectedUsers.length === 0) {
      alert('请输入群组名称并选择至少一个成员');
      return;
    }

    try {
      await axios.post('/api/groups/create', {
        name: groupName,
        memberIds: selectedUsers
      });
      setShowCreateGroup(false);
      setGroupName('');
      setSelectedUsers([]);
      loadChats();
    } catch (error) {
      alert('创建群组失败');
    }
  };

  const formatTime = (timestamp) => {
    if (!timestamp) return '';
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now - date;

    if (diff < 60000) return '刚刚';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}分钟前`;
    if (diff < 86400000) return date.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
    return date.toLocaleDateString('zh-CN', { month: '2-digit', day: '2-digit' });
  };

  const formatLastMessage = (msg) => {
    if (!msg) return '暂无消息';
    if (msg.type === 'image') return '[图片]';
    return msg.content.length > 20 ? msg.content.substring(0, 20) + '...' : msg.content;
  };

  return (
    <div className="h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b px-4 py-3 flex items-center justify-between">
        <h1 className="text-xl font-semibold text-gray-800">微信</h1>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowAddFriend(true)}
            className="p-2 hover:bg-gray-100 rounded-full transition"
          >
            <svg className="w-6 h-6 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
            </svg>
          </button>
          <button
            onClick={() => setShowCreateGroup(true)}
            className="p-2 hover:bg-gray-100 rounded-full transition"
          >
            <svg className="w-6 h-6 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
            </svg>
          </button>
          <button
            onClick={logout}
            className="p-2 hover:bg-gray-100 rounded-full transition"
          >
            <svg className="w-6 h-6 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
            </svg>
          </button>
        </div>
      </div>

      {/* Chat List */}
      <div className="flex-1 overflow-y-auto">
        {loading ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-gray-400">加载中...</div>
          </div>
        ) : chats.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-gray-400">
            <svg className="w-20 h-20 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
            </svg>
            <p>暂无聊天记录</p>
            <p className="text-sm mt-2">点击右上角添加好友或创建群组</p>
          </div>
        ) : (
          chats.map((chat) => (
            <div
              key={`${chat.type}-${chat.id}`}
              onClick={() => navigate(`/chat/${chat.type}/${chat.id}`)}
              className="flex items-center gap-3 px-4 py-3 hover:bg-gray-100 cursor-pointer border-b border-gray-100 transition"
            >
              <div className="relative">
                <img
                  src={chat.avatar}
                  alt={chat.name}
                  className="w-12 h-12 rounded-lg object-cover"
                />
                {chat.type === 'private' && chat.online && (
                  <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <h3 className="font-medium text-gray-900 truncate">{chat.name}</h3>
                  <span className="text-xs text-gray-400 ml-2 flex-shrink-0">
                    {formatTime(chat.lastMessage?.timestamp)}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <p className="text-sm text-gray-500 truncate">
                    {chat.lastMessage?.sender && chat.type === 'group' && (
                      <span className="text-gray-400">{chat.lastMessage.sender}: </span>
                    )}
                    {formatLastMessage(chat.lastMessage)}
                  </p>
                  {chat.unreadCount > 0 && (
                    <span className="ml-2 bg-red-500 text-white text-xs rounded-full px-2 py-0.5 flex-shrink-0">
                      {chat.unreadCount > 99 ? '99+' : chat.unreadCount}
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Add Friend Modal */}
      {showAddFriend && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md mx-4 max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold">添加好友</h2>
              <button onClick={() => setShowAddFriend(false)} className="text-gray-400 hover:text-gray-600">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            <div className="space-y-2">
              {users.length === 0 ? (
                <p className="text-gray-400 text-center py-4">没有可添加的用户</p>
              ) : (
                users.map((u) => (
                  <div key={u._id} className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <img src={u.avatar} alt={u.username} className="w-10 h-10 rounded-full" />
                      <div>
                        <p className="font-medium">{u.username}</p>
                        <p className="text-xs text-gray-400">{u.online ? '在线' : '离线'}</p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleAddFriend(u._id)}
                      className="px-4 py-1.5 bg-green-500 text-white rounded-full text-sm hover:bg-green-600 transition"
                    >
                      添加
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Create Group Modal */}
      {showCreateGroup && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md mx-4 max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold">创建群组</h2>
              <button onClick={() => setShowCreateGroup(false)} className="text-gray-400 hover:text-gray-600">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            <input
              type="text"
              value={groupName}
              onChange={(e) => setGroupName(e.target.value)}
              placeholder="群组名称"
              className="w-full px-4 py-2 border rounded-lg mb-4 focus:ring-2 focus:ring-green-500 focus:border-transparent"
            />
            <div className="space-y-2">
              {users.map((u) => (
                <div
                  key={u._id}
                  onClick={() => {
                    if (selectedUsers.includes(u._id)) {
                      setSelectedUsers(selectedUsers.filter(id => id !== u._id));
                    } else {
                      setSelectedUsers([...selectedUsers, u._id]);
                    }
                  }}
                  className={`flex items-center justify-between p-3 rounded-lg cursor-pointer ${
                    selectedUsers.includes(u._id) ? 'bg-green-50' : 'hover:bg-gray-50'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <img src={u.avatar} alt={u.username} className="w-10 h-10 rounded-full" />
                    <p className="font-medium">{u.username}</p>
                  </div>
                  {selectedUsers.includes(u._id) && (
                    <svg className="w-5 h-5 text-green-500" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  )}
                </div>
              ))}
            </div>
            <button
              onClick={handleCreateGroup}
              className="w-full mt-4 bg-green-500 text-white py-3 rounded-lg hover:bg-green-600 transition"
            >
              创建群组
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ChatList;

