import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';

const ConversationsPage = () => {
  const [conversations, setConversations] = useState([]);
  const [users, setUsers] = useState([]);
  const [showAddContact, setShowAddContact] = useState(false);
  const [showCreateGroup, setShowCreateGroup] = useState(false);
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [groupName, setGroupName] = useState('');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [pullDistance, setPullDistance] = useState(0);
  const [startY, setStartY] = useState(0);
  const [isPulling, setIsPulling] = useState(false);
  const { user, socket } = useAuth();
  const navigate = useNavigate();
  const listRef = useRef(null);

  useEffect(() => {
    loadConversations();
    loadUsers();

    if (socket) {
      socket.on('message', handleNewMessage);
      socket.on('group_message', handleNewMessage);
      socket.on('user_online', handleUserOnline);
      socket.on('service_request', handleServiceNotification);
    }

    return () => {
      if (socket) {
        socket.off('message', handleNewMessage);
        socket.off('group_message', handleNewMessage);
        socket.off('user_online', handleUserOnline);
        socket.off('service_request', handleServiceNotification);
      }
    };
  }, [socket]);

  const loadConversations = async () => {
    try {
      const response = await axios.get('/api/chats');
      // 模拟佳士得专业数据
      const christiesConversations = response.data.map(chat => ({
        ...chat,
        professionalTitle: chat.type === 'private' ? 
          ['艺术顾问', '鉴定专家', '拍卖师', '客户经理'][Math.floor(Math.random() * 4)] : 
          null,
        department: chat.type === 'group' ? 
          ['珠宝部', '书画部', '古董部', '现代艺术部'][Math.floor(Math.random() * 4)] : 
          null,
        lastMessageType: chat.lastMessage?.type || 'text',
        fileType: chat.lastMessage?.type === 'file' ? 
          ['鉴定报告.pdf', '拍卖图录.pdf', '委托协议.pdf'][Math.floor(Math.random() * 3)] : 
          null
      }));
      setConversations(christiesConversations);
    } catch (error) {
      console.error('Failed to load conversations:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const loadUsers = async () => {
    try {
      const response = await axios.get('/api/users');
      setUsers(response.data);
    } catch (error) {
      console.error('Failed to load users:', error);
    }
  };

  const handleNewMessage = () => {
    loadConversations();
  };

  const handleUserOnline = (data) => {
    setConversations(prevConversations =>
      prevConversations.map(conversation =>
        conversation.type === 'private' && conversation.id === data.userId
          ? { ...conversation, online: data.online, lastSeen: data.lastSeen }
          : conversation
      )
    );
  };

  const handleServiceNotification = (data) => {
    if (data.type === 'service_added') {
      // 显示佳士得风格通知
      const notification = document.createElement('div');
      notification.className = 'fixed top-4 left-1/2 transform -translate-x-1/2 warm-gold-bg text-white px-6 py-3 rounded-soft shadow-gentle z-50 soft-slide-in';
      notification.innerHTML = `
        <div class="flex items-center gap-2">
          <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
          </svg>
          <span>${data.message}</span>
        </div>
      `;
      document.body.appendChild(notification);
      
      setTimeout(() => {
        notification.remove();
      }, 4000);
      
      loadConversations();
    }
  };

  const handleAddContact = async (contactId) => {
    try {
      await axios.post('/api/friends/add', { friendId: contactId });
      setShowAddContact(false);
      loadConversations();
      loadUsers();
    } catch (error) {
      alert('添加联系人失败');
    }
  };

  const handleCreateGroup = async () => {
    if (!groupName.trim() || selectedUsers.length === 0) {
      alert('请输入群组名称并选择至少一个成员');
      return;
    }

    try {
      await axios.post('/api/groups/create', {
        name: groupName,
        memberIds: selectedUsers
      });
      setShowCreateGroup(false);
      setGroupName('');
      setSelectedUsers([]);
      loadConversations();
    } catch (error) {
      alert('创建群组失败');
    }
  };

  const formatTime = (timestamp) => {
    if (!timestamp) return '';
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now - date;

    if (diff < 60000) return '刚刚';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}分钟前`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}小时前`;
    return date.toLocaleDateString('zh-CN', { month: '2-digit', day: '2-digit' });
  };

  const formatLastMessage = (conversation) => {
    if (!conversation.lastMessage) return '暂无消息';
    
    if (conversation.lastMessage.type === 'image') return '📷 图片';
    if (conversation.lastMessage.type === 'file') {
      return `📄 ${conversation.fileType || '文件'}`;
    }
    
    const content = conversation.lastMessage.content;
    return content.length > 20 ? content.substring(0, 20) + '...' : content;
  };

  const getConversationIcon = (conversation) => {
    if (conversation.type === 'group') {
      // 部门群聊用宝石图标
      return (
        <div className="relative">
          <div className="avatar-soft bg-gradient-to-br from-warm-gold to-yellow-600 flex items-center justify-center">
            <span className="text-white text-lg">💎</span>
          </div>
          <div className="absolute -bottom-1 -right-1 bg-soft-blue text-white text-xs rounded-full w-5 h-5 flex items-center justify-center shadow-soft">
            {conversation.memberCount || 'G'}
          </div>
        </div>
      );
    } else {
      return (
        <div className="relative">
          <img
            src={conversation.avatar}
            alt={conversation.name}
            className="avatar-soft"
          />
          {conversation.online && (
            <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white breathing"></div>
          )}
        </div>
      );
    }
  };

  const getConversationTypeIndicator = (conversation) => {
    if (conversation.type === 'group') {
      return (
        <div className="flex items-center gap-1">
          <span className="text-sm text-muted">·</span>
          <span className="text-sm text-muted">{conversation.department}</span>
        </div>
      );
    } else {
      return (
        <div className="flex items-center gap-1">
          <span className="text-sm text-muted">·</span>
          <span className="text-sm text-muted">{conversation.professionalTitle}</span>
        </div>
      );
    }
  };

  // 下拉刷新处理
  const handleTouchStart = (e) => {
    if (listRef.current.scrollTop === 0) {
      setStartY(e.touches[0].clientY);
      setIsPulling(true);
    }
  };

  const handleTouchMove = (e) => {
    if (isPulling && listRef.current.scrollTop === 0) {
      const currentY = e.touches[0].clientY;
      const distance = Math.max(0, currentY - startY);
      setPullDistance(Math.min(distance, 80));
    }
  };

  const handleTouchEnd = () => {
    if (isPulling && pullDistance > 50) {
      setRefreshing(true);
      loadConversations();
    }
    setPullDistance(0);
    setIsPulling(false);
  };

  const EmptyState = () => (
    <div className="empty-state-soft">
      <svg className="empty-state-icon-soft" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
      </svg>
      <h3 className="empty-state-title-soft">暂无对话记录</h3>
      <p className="empty-state-desc-soft">点击右上角添加专业顾问或创建部门群组<br/>开始您的佳士得专属服务之旅</p>
    </div>
  );

  return (
    <div className="h-full flex flex-col warm-cream pb-16">
      {/* Header */}
      <div className="soft-blue-bg text-white px-6 py-4 flex items-center justify-between safe-area-pt shadow-gentle">
        <h1 className="text-hierarchy-1 text-white">对话</h1>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowAddContact(true)}
            className="p-2 hover:bg-white/20 rounded-soft transition-all duration-300 hover:scale-110 relative"
            title="添加专业顾问"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
            </svg>
            {/* 添加联系人提示 */}
            <div className="absolute -top-1 -right-1 w-3 h-3 bg-warm-gold rounded-full gentle-pulse"></div>
          </button>
          <button
            onClick={() => setShowCreateGroup(true)}
            className="p-2 hover:bg-white/20 rounded-soft transition-all duration-300 hover:scale-110"
            title="创建部门群组"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
            </svg>
          </button>
        </div>
      </div>

      {/* Conversation List */}
      <div 
        ref={listRef}
        className="flex-1 overflow-y-auto scroll-smooth"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {/* 下拉刷新指示器 */}
        <div 
          className="absolute top-0 left-0 right-0 h-16 flex items-center justify-center warm-cream transition-transform duration-300"
          style={{ transform: `translateY(${pullDistance - 60}px)` }}
        >
          {refreshing ? (
            <div className="flex items-center gap-2 text-muted">
              <div className="w-4 h-4 border-2 border-warm-gold border-t-transparent rounded-full animate-spin"></div>
              <span>正在更新...</span>
            </div>
          ) : pullDistance > 50 ? (
            <span className="text-muted">释放刷新</span>
          ) : (
            <span className="text-muted">下拉刷新</span>
          )}
        </div>

        {loading ? (
          <div className="flex items-center justify-center h-full">
            <div className="w-6 h-6 border-2 border-warm-gold border-t-transparent rounded-full animate-spin"></div>
            <span className="ml-3 text-muted">加载中...</span>
          </div>
        ) : conversations.length === 0 ? (
          <EmptyState />
        ) : (
          <div className="p-6 space-y-3">
            {conversations.map((conversation, index) => (
              <div
                key={`${conversation.type}-${conversation.id}`}
                onClick={() => navigate(`/chat/${conversation.type}/${conversation.id}`)}
                className="soft-card p-4 cursor-pointer gentle-fade-in list-item-soft"
                style={{ animationDelay: `${index * 0.05}s` }}
              >
                <div className="flex items-center gap-4">
                  {getConversationIcon(conversation)}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-1">
                        <span className="text-hierarchy-2 text-primary truncate">{conversation.name}</span>
                        {getConversationTypeIndicator(conversation)}
                      </div>
                      <span className="time-relative-soft flex-shrink-0">
                        {formatTime(conversation.lastMessage?.timestamp)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <p className="text-hierarchy-3 text-secondary truncate">
                        {conversation.lastMessage?.sender && conversation.type === 'group' && (
                          <span className="text-muted">{conversation.lastMessage.sender}: </span>
                        )}
                        {formatLastMessage(conversation)}
                      </p>
                      {conversation.unreadCount > 0 && (
                        <div className="unread-badge-soft ml-2 flex-shrink-0">
                          {conversation.unreadCount > 99 ? '99+' : conversation.unreadCount}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add Contact Modal */}
      {showAddContact && (
        <div className="modal-overlay-soft">
          <div className="modal-content-soft">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-hierarchy-1 text-primary">添加专业顾问</h2>
              <button 
                onClick={() => setShowAddContact(false)} 
                className="text-muted hover:text-primary transition-colors"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            <div className="space-y-3">
              {users.length === 0 ? (
                <p className="text-muted text-center py-4">没有可添加的专业顾问</p>
              ) : (
                users.map((u) => (
                  <div key={u._id} className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-soft transition-colors">
                    <div className="flex items-center gap-3">
                      <img src={u.avatar} alt={u.username} className="avatar-soft-small" />
                      <div>
                        <p className="text-hierarchy-3 text-primary">{u.username}</p>
                        <p className="text-hierarchy-4 text-muted">{u.online ? '在线' : '离线'}</p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleAddContact(u._id)}
                      className="btn-gold px-4 py-1.5 text-sm"
                    >
                      添加
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Create Group Modal */}
      {showCreateGroup && (
        <div className="modal-overlay-soft">
          <div className="modal-content-soft">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-hierarchy-1 text-primary">创建部门群组</h2>
              <button 
                onClick={() => setShowCreateGroup(false)} 
                className="text-muted hover:text-primary transition-colors"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            <input
              type="text"
              value={groupName}
              onChange={(e) => setGroupName(e.target.value)}
              placeholder="部门群组名称"
              className="input-soft w-full mb-6"
            />
            <div className="space-y-3">
              {users.map((u) => (
                <div
                  key={u._id}
                  onClick={() => {
                    if (selectedUsers.includes(u._id)) {
                      setSelectedUsers(selectedUsers.filter(id => id !== u._id));
                    } else {
                      setSelectedUsers([...selectedUsers, u._id]);
                    }
                  }}
                  className={`flex items-center justify-between p-3 rounded-soft cursor-pointer transition-all duration-300 ${
                    selectedUsers.includes(u._id) ? 'bg-warm-gold/10 scale-105' : 'hover:bg-gray-50'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <img src={u.avatar} alt={u.username} className="avatar-soft-small" />
                    <p className="text-hierarchy-3 text-primary">{u.username}</p>
                  </div>
                  {selectedUsers.includes(u._id) && (
                    <svg className="w-5 h-5 warm-gold" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  )}
                </div>
              ))}
            </div>
            <button
              onClick={handleCreateGroup}
              className="btn-soft w-full mt-6"
            >
              创建部门群组
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ConversationsPage;
