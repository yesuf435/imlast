import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';

const ContactsPage = () => {
  const [friends, setFriends] = useState([]);
  const [groups, setGroups] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('friends'); // friends, groups
  const { user, socket } = useAuth();

  useEffect(() => {
    loadData();
    
    if (socket) {
      socket.on('friend_request', handleFriendNotification);
    }

    return () => {
      if (socket) {
        socket.off('friend_request', handleFriendNotification);
      }
    };
  }, [socket]);

  const loadData = async () => {
    try {
      const chatsResponse = await axios.get('/api/chats');
      
      // 分离好友和群聊
      const friendsList = chatsResponse.data
        .filter(chat => chat.type === 'private')
        .map(chat => ({
          ...chat,
          id: chat.id,
          username: chat.name,
          avatar: chat.avatar,
          online: chat.online,
          lastSeen: chat.lastSeen
        }));
      
      const groupsList = chatsResponse.data
        .filter(chat => chat.type === 'group')
        .map(chat => ({
          ...chat,
          id: chat.id,
          name: chat.name,
          avatar: chat.avatar,
          memberCount: chat.memberCount || 0
        }));
      
      setFriends(friendsList);
      setGroups(groupsList);
    } catch (error) {
      console.error('Failed to load data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleFriendNotification = (data) => {
    if (data.type === 'friend_added') {
      // 显示更明显的通知
      const notification = document.createElement('div');
      notification.className = 'fixed top-4 left-1/2 transform -translate-x-1/2 primary-bg text-white px-6 py-3 rounded-button shadow-card z-50 slide-in-right';
      notification.innerHTML = `
        <div class="flex items-center gap-2">
          <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
          </svg>
          <span>${data.message}</span>
        </div>
      `;
      document.body.appendChild(notification);
      
      setTimeout(() => {
        notification.remove();
      }, 4000);
      
      loadData();
    }
  };

  const formatLastSeen = (lastSeen) => {
    if (!lastSeen) return '';
    const date = new Date(lastSeen);
    const now = new Date();
    const diff = now - date;

    if (diff < 60000) return '刚刚';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}分钟前`;
    if (diff < 86400000) return date.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
    return date.toLocaleDateString('zh-CN', { month: '2-digit', day: '2-digit' });
  };

  const renderFriendItem = (friend, index) => (
    <div 
      key={friend._id || friend.id} 
      className="list-item p-4 transition-all duration-200 hover:shadow-lg hover:scale-105 slide-in"
      style={{ animationDelay: `${index * 0.05}s` }}
    >
      <div className="flex items-center gap-3">
        <div className="relative">
          <img
            src={friend.avatar}
            alt={friend.username}
            className="avatar"
          />
          {friend.online && (
            <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white breathing"></div>
          )}
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-primary truncate">{friend.username}</h3>
          <p className="text-sm text-secondary truncate">
            {friend.online ? '在线' : `最后在线 ${formatLastSeen(friend.lastSeen)}`}
          </p>
        </div>
        <div className="flex items-center gap-1">
          <svg className="w-4 h-4 text-green-500" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd"></path>
          </svg>
          <span className="text-xs text-green-500 font-medium">私聊</span>
        </div>
      </div>
    </div>
  );

  const renderGroupItem = (group, index) => (
    <div 
      key={group._id || group.id} 
      className="list-item p-4 transition-all duration-200 hover:shadow-lg hover:scale-105 slide-in"
      style={{ animationDelay: `${index * 0.05}s` }}
    >
      <div className="flex items-center gap-3">
        <div className="relative">
          <img
            src={group.avatar}
            alt={group.name}
            className="avatar"
          />
          <div className="absolute -bottom-1 -right-1 bg-blue-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center shadow-card">
            {group.memberCount}
          </div>
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-primary truncate">{group.name}</h3>
          <p className="text-sm text-secondary truncate">
            {group.memberCount}人
          </p>
        </div>
        <div className="flex items-center gap-1">
          <svg className="w-4 h-4 text-blue-500" fill="currentColor" viewBox="0 0 20 20">
            <path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z"></path>
          </svg>
          <span className="text-xs text-blue-500 font-medium">群聊</span>
        </div>
      </div>
    </div>
  );

  const EmptyState = ({ type }) => (
    <div className="empty-state">
      <svg className="empty-state-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
      </svg>
      <h3 className="empty-state-title">暂无{type === 'friends' ? '好友' : '群聊'}</h3>
      <p className="empty-state-desc">去消息页面{type === 'friends' ? '添加好友' : '创建群组'}吧<br/>开始您的{type === 'friends' ? '社交' : '团队协作'}之旅</p>
    </div>
  );

  return (
    <div className="h-full bg-page pb-16">
      {/* Header */}
      <div className="primary-bg text-white px-4 py-3 safe-area-pt shadow-card">
        <h1 className="text-xl font-semibold">服务团队</h1>
      </div>

      {/* Tab Navigation */}
      <div className="bg-white border-b shadow-sm">
        <div className="flex">
          <button
            onClick={() => setActiveTab('friends')}
            className={`flex-1 py-3 text-center font-medium transition-all duration-200 tab-item ${
              activeTab === 'friends' ? 'active' : ''
            }`}
          >
            好友 ({friends.length})
          </button>
          <button
            onClick={() => setActiveTab('groups')}
            className={`flex-1 py-3 text-center font-medium transition-all duration-200 tab-item ${
              activeTab === 'groups' ? 'active' : ''
            }`}
          >
            群聊 ({groups.length})
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto scroll-smooth">
        {loading ? (
          <div className="flex items-center justify-center h-full">
            <div className="loading-spinner"></div>
            <span className="ml-2 text-tertiary">加载中...</span>
          </div>
        ) : (
          <div className="p-4 space-y-2">
            {activeTab === 'friends' ? (
              friends.length === 0 ? (
                <EmptyState type="friends" />
              ) : (
                friends.map((friend, index) => renderFriendItem(friend, index))
              )
            ) : (
              groups.length === 0 ? (
                <EmptyState type="groups" />
              ) : (
                groups.map((group, index) => renderGroupItem(group, index))
              )
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default ContactsPage;
