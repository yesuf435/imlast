import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';

const ChatWindow = () => {
  const { type, id } = useParams();
  const navigate = useNavigate();
  const { user, socket } = useAuth();
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [typing, setTyping] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [showContextMenu, setShowContextMenu] = useState(false);
  const [contextMenuPosition, setContextMenuPosition] = useState({ x: 0, y: 0 });
  const [selectedMessage, setSelectedMessage] = useState(null);
  const messagesEndRef = useRef(null);
  const fileInputRef = useRef(null);
  const imageInputRef = useRef(null);
  const typingTimeoutRef = useRef(null);

  useEffect(() => {
    loadMessages();
    
    if (socket) {
      socket.emit('join', { type, id });
      socket.on('message', handleNewMessage);
      socket.on('group_message', handleNewMessage);
      socket.on('typing', handleTyping);
      socket.on('message_status', handleMessageStatus);
    }

    return () => {
      if (socket) {
        socket.off('message', handleNewMessage);
        socket.off('group_message', handleNewMessage);
        socket.off('typing', handleTyping);
        socket.off('message_status', handleMessageStatus);
      }
    };
  }, [type, id, socket]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const loadMessages = async () => {
    try {
      const response = await axios.get(`/api/messages/${id}`);
      setMessages(response.data);
    } catch (error) {
      console.error('Failed to load messages:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleNewMessage = (data) => {
    if (data.chatId === id) {
      setMessages(prev => [...prev, data]);
    }
  };

  const handleTyping = (data) => {
    if (data.chatId === id && data.userId !== user.id) {
      setTyping(true);
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
      typingTimeoutRef.current = setTimeout(() => {
        setTyping(false);
      }, 2000);
    }
  };

  const handleMessageStatus = (data) => {
    setMessages(prev => 
      prev.map(msg => 
        msg._id === data.messageId 
          ? { ...msg, status: data.status }
          : msg
      )
    );
  };

  const sendMessage = async () => {
    if (!newMessage.trim() || sending) return;

    const messageData = {
      content: newMessage.trim(),
      type: 'text',
      chatId: id,
      chatType: type
    };

    setSending(true);
    setNewMessage('');

    // 乐观更新
    const tempMessage = {
      _id: Date.now().toString(),
      content: messageData.content,
      type: 'text',
      sender: { _id: user.id, username: user.username, avatar: user.avatar },
      timestamp: new Date(),
      status: 'sending'
    };
    setMessages(prev => [...prev, tempMessage]);

    try {
      if (type === 'group') {
        socket.emit('group_message', messageData);
      } else {
        socket.emit('message', messageData);
      }
    } catch (error) {
      console.error('Failed to send message:', error);
      // 移除失败的消息
      setMessages(prev => prev.filter(msg => msg._id !== tempMessage._id));
    } finally {
      setSending(false);
    }
  };

  const uploadFile = async (file) => {
    const formData = new FormData();
    formData.append('file', file);

    try {
      setUploading(true);
      const response = await axios.post('/api/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });

      const messageData = {
        content: response.data.url,
        type: file.type.startsWith('image/') ? 'image' : 'file',
        fileName: file.name,
        fileSize: file.size,
        chatId: id,
        chatType: type
      };

      if (type === 'group') {
        socket.emit('group_message', messageData);
      } else {
        socket.emit('message', messageData);
      }
    } catch (error) {
      console.error('Upload failed:', error);
      alert('文件上传失败');
    } finally {
      setUploading(false);
    }
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      uploadFile(file);
    }
  };

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      uploadFile(file);
    }
  };

  const handleTypingStart = () => {
    if (socket) {
      socket.emit('typing', { chatId: id, userId: user.id });
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const formatMessageTime = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now - date;

    if (diff < 60000) return '刚刚';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}分钟前`;
    if (diff < 86400000) return date.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
    return date.toLocaleDateString('zh-CN', { month: '2-digit', day: '2-digit' });
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleMessageLongPress = (message, e) => {
    e.preventDefault();
    setSelectedMessage(message);
    setContextMenuPosition({ x: e.touches[0].clientX, y: e.touches[0].clientY });
    setShowContextMenu(true);
  };

  const handleContextMenuAction = (action) => {
    if (selectedMessage) {
      switch (action) {
        case 'copy':
          navigator.clipboard.writeText(selectedMessage.content);
          break;
        case 'delete':
          // 实现删除消息逻辑
          break;
        case 'forward':
          // 实现转发消息逻辑
          break;
      }
    }
    setShowContextMenu(false);
    setSelectedMessage(null);
  };

  const getMessageStatusIcon = (status) => {
    switch (status) {
      case 'sending':
        return (
          <div className="message-status message-status-sending">
            <div className="loading-spinner w-3 h-3"></div>
          </div>
        );
      case 'sent':
        return (
          <div className="message-status message-status-sent">
            <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
            </svg>
          </div>
        );
      case 'read':
        return (
          <div className="message-status message-status-read">
            <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
            </svg>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="h-full flex flex-col bg-page">
      {/* Header */}
      <div className="primary-bg text-white px-4 py-3 flex items-center justify-between safe-area-pt shadow-card">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate(-1)}
            className="p-1 hover:bg-white/20 rounded-button transition-colors"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <div>
            <h1 className="text-lg font-semibold">{type === 'group' ? '群聊' : '私聊'}</h1>
            <p className="text-sm opacity-90">{id}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button className="p-2 hover:bg-white/20 rounded-button transition-colors">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z" />
            </svg>
          </button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto scroll-smooth p-4 space-y-4">
        {loading ? (
          <div className="flex items-center justify-center h-full">
            <div className="loading-spinner"></div>
            <span className="ml-2 text-tertiary">加载中...</span>
          </div>
        ) : (
          messages.map((message, index) => {
            const isOwn = message.sender._id === user.id;
            return (
              <div key={message._id || index} className={`flex ${isOwn ? 'justify-end' : 'justify-start'} fade-in`}>
                <div className={`flex items-end gap-2 max-w-xs ${isOwn ? 'flex-row-reverse' : 'flex-row'}`}>
                  {!isOwn && (
                    <img
                      src={message.sender.avatar}
                      alt={message.sender.username}
                      className="avatar-small"
                    />
                  )}
                  <div className={`px-4 py-2 rounded-button ${
                    isOwn ? 'chat-bubble-own' : 'chat-bubble-other'
                  }`}>
                    {message.type === 'image' ? (
                      <div>
                        <img
                          src={message.content}
                          alt="图片"
                          className="max-w-xs rounded-button cursor-pointer"
                          onClick={() => window.open(message.content, '_blank')}
                        />
                        <p className={`text-xs mt-1 ${
                          isOwn ? 'text-white/80' : 'text-tertiary'
                        }`}>
                          {formatMessageTime(message.timestamp)}
                        </p>
                      </div>
                    ) : message.type === 'file' ? (
                      <div>
                        <div className="flex items-center gap-2 p-2 bg-white/20 rounded-button">
                          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                          </svg>
                          <div className="flex-1">
                            <p className="text-sm font-medium">{message.fileName}</p>
                            <p className="text-xs opacity-70">{formatFileSize(message.fileSize)}</p>
                          </div>
                          <a
                            href={message.content}
                            download={message.fileName}
                            className="opacity-70 hover:opacity-100 transition-opacity"
                          >
                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
                              <path strokeLinecap="round" strokeLinejoin="round" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                            </svg>
                          </a>
                        </div>
                        <p className={`text-xs mt-1 ${
                          isOwn ? 'text-white/80' : 'text-tertiary'
                        }`}>
                          {formatMessageTime(message.timestamp)}
                        </p>
                      </div>
                    ) : (
                      <div>
                        <p className="text-sm">{message.content}</p>
                        <div className="flex items-center justify-between mt-1">
                          <p className={`text-xs ${
                            isOwn ? 'text-white/80' : 'text-tertiary'
                          }`}>
                            {formatMessageTime(message.timestamp)}
                          </p>
                          {isOwn && getMessageStatusIcon(message.status)}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
        
        {/* 输入状态 */}
        {typing && (
          <div className="flex items-center gap-2 text-tertiary">
            <div className="typing flex gap-1">
              <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
              <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
              <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
            </div>
            <span className="text-sm">正在输入...</span>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="bg-white border-t p-4 safe-area-pb shadow-card">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            {/* 表情按钮 */}
            <button className="p-2 hover:bg-gray-100 rounded-button transition-colors">
              <svg className="w-6 h-6 text-tertiary" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </button>
            
            {/* 图片上传按钮 */}
            <button
              onClick={() => imageInputRef.current?.click()}
              disabled={uploading}
              className="p-2 hover:bg-gray-100 rounded-button transition-colors disabled:opacity-50"
            >
              <svg className="w-6 h-6 text-tertiary" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
            </button>
            
            {/* 文件上传按钮 */}
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={uploading}
              className="p-2 hover:bg-gray-100 rounded-button transition-colors disabled:opacity-50"
            >
              <svg className="w-6 h-6 text-tertiary" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
              </svg>
            </button>
          </div>
          
          <div className="flex-1 flex items-center gap-2">
            <input
              type="text"
              value={newMessage}
              onChange={(e) => {
                setNewMessage(e.target.value);
                handleTypingStart();
              }}
              onKeyPress={handleKeyPress}
              placeholder="输入消息..."
              className="input-field flex-1"
            />
            <button
              onClick={sendMessage}
              disabled={!newMessage.trim() || sending || uploading}
              className={`px-4 py-2 rounded-button transition-all duration-200 ${
                newMessage.trim() && !sending && !uploading
                  ? 'btn-primary'
                  : 'bg-gray-300 text-gray-500 cursor-not-allowed'
              }`}
            >
              {sending || uploading ? (
                <div className="loading-spinner w-5 h-5"></div>
              ) : (
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                </svg>
              )}
            </button>
          </div>
          
          {/* 隐藏的文件输入 */}
          <input
            ref={imageInputRef}
            type="file"
            accept="image/*"
            onChange={handleImageUpload}
            className="hidden"
          />
          <input
            ref={fileInputRef}
            type="file"
            onChange={handleFileUpload}
            className="hidden"
          />
        </div>
      </div>

      {/* 长按菜单 */}
      {showContextMenu && (
        <div
          className="context-menu"
          style={{
            left: contextMenuPosition.x,
            top: contextMenuPosition.y,
          }}
        >
          <div className="context-menu-item" onClick={() => handleContextMenuAction('copy')}>
            <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
            </svg>
            复制
          </div>
          <div className="context-menu-item" onClick={() => handleContextMenuAction('forward')}>
            <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
            </svg>
            转发
          </div>
          <div className="context-menu-item" onClick={() => handleContextMenuAction('delete')}>
            <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
            </svg>
            删除
          </div>
        </div>
      )}
    </div>
  );
};

export default ChatWindow;
