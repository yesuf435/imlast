import React, { useState } from 'react';

const NotificationsPage = () => {
  const [notifications] = useState([
    {
      id: 1,
      title: '系统通知',
      content: '欢迎使用佳士得专属服务',
      time: '2025-10-11 10:00',
      read: false,
      type: 'system'
    },
    {
      id: 2,
      title: '服务邀请',
      content: '张明顾问请求为您服务',
      time: '2025-10-11 09:30',
      read: false,
      type: 'service'
    },
    {
      id: 3,
      title: '拍卖提醒',
      content: '中国书画专场即将开始',
      time: '2025-10-11 09:00',
      read: true,
      type: 'auction'
    },
    {
      id: 4,
      title: '文件待确认',
      content: '委托协议需您审阅',
      time: '2025-10-10 18:00',
      read: true,
      type: 'document'
    }
  ]);

  const getNotificationIcon = (type) => {
    switch (type) {
      case 'system':
        return '🏛️';
      case 'service':
        return '👥';
      case 'auction':
        return '🎯';
      case 'document':
        return '📄';
      default:
        return '📢';
    }
  };

  const getTypeLabel = (type) => {
    switch (type) {
      case 'system':
        return '系统';
      case 'service':
        return '服务';
      case 'auction':
        return '拍卖';
      case 'document':
        return '文件';
      default:
        return '通知';
    }
  };

  const formatTime = (time) => {
    const date = new Date(time);
    const now = new Date();
    const diff = now - date;

    if (diff < 60000) return '刚刚';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}分钟前`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}小时前`;
    if (diff < 604800000) return `${Math.floor(diff / 86400000)}天前`;
    return date.toLocaleDateString('zh-CN', { month: '2-digit', day: '2-digit' });
  };

  const handleAcceptService = (notificationId) => {
    // 实现接受服务邀请逻辑
    console.log('Accept service invitation:', notificationId);
  };

  const handleRejectService = (notificationId) => {
    // 实现拒绝服务邀请逻辑
    console.log('Reject service invitation:', notificationId);
  };

  const handleViewAuction = (notificationId) => {
    // 实现查看拍卖详情逻辑
    console.log('View auction details:', notificationId);
  };

  const handleViewDocument = (notificationId) => {
    // 实现查看文件详情逻辑
    console.log('View document details:', notificationId);
  };

  const EmptyState = () => (
    <div className="empty-state-soft">
      <svg className="empty-state-icon-soft" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 17h5l-5 5v-5zM4.5 19.5a2.5 2.5 0 01-2.5-2.5V7a2.5 2.5 0 012.5-2.5h15a2.5 2.5 0 012.5 2.5v10a2.5 2.5 0 01-2.5 2.5h-15z" />
      </svg>
      <h3 className="empty-state-title-soft">暂无通知</h3>
      <p className="empty-state-desc-soft">所有重要通知都会在这里显示<br/>保持关注，不错过任何佳士得专属服务</p>
    </div>
  );

  return (
    <div className="h-full warm-cream pb-16">
      {/* Header */}
      <div className="soft-blue-bg text-white px-6 py-4 safe-area-pt shadow-gentle">
        <h1 className="text-hierarchy-1 text-white">通知</h1>
      </div>
      
      {/* Content */}
      <div className="p-6">
        {notifications.length === 0 ? (
          <EmptyState />
        ) : (
          <div className="space-y-4">
            {notifications.map((notification, index) => (
              <div
                key={notification.id}
                className={`soft-card p-5 transition-all duration-300 hover:shadow-gentle hover:scale-105 gentle-fade-in ${
                  notification.read ? 'opacity-75' : ''
                }`}
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="flex items-start gap-4">
                  <div className="text-2xl flex-shrink-0 mt-1">
                    {getNotificationIcon(notification.type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <h3 className={`text-hierarchy-2 ${notification.read ? 'text-secondary' : 'text-primary'}`}>
                          {notification.title}
                        </h3>
                        <span className="text-hierarchy-4 text-muted">·</span>
                        <span className="text-hierarchy-4 text-muted">{getTypeLabel(notification.type)}</span>
                      </div>
                      <span className="time-relative-soft">{formatTime(notification.time)}</span>
                    </div>
                    <p className={`text-hierarchy-3 mb-3 ${notification.read ? 'text-secondary' : 'text-primary'}`}>
                      {notification.content}
                    </p>
                    
                    {/* 操作按钮 */}
                    {!notification.read && (
                      <div className="flex gap-3">
                        {notification.type === 'service' && (
                          <>
                            <button
                              onClick={() => handleAcceptService(notification.id)}
                              className="btn-gold px-4 py-2 text-sm"
                            >
                              接受
                            </button>
                            <button
                              onClick={() => handleRejectService(notification.id)}
                              className="btn-ghost px-4 py-2 text-sm"
                            >
                              婉拒
                            </button>
                          </>
                        )}
                        {notification.type === 'auction' && (
                          <button
                            onClick={() => handleViewAuction(notification.id)}
                            className="btn-soft px-4 py-2 text-sm"
                          >
                            查看详情
                          </button>
                        )}
                        {notification.type === 'document' && (
                          <button
                            onClick={() => handleViewDocument(notification.id)}
                            className="btn-soft px-4 py-2 text-sm"
                          >
                            查看详情
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                  {!notification.read && (
                    <div className="unread-dot-soft flex-shrink-0"></div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default NotificationsPage;
