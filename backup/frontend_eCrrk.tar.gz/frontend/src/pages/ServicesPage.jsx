import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';

const ServicesPage = () => {
  const [advisors, setAdvisors] = useState([]);
  const [experts, setExperts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('advisors'); // advisors, experts
  const { user, socket } = useAuth();

  useEffect(() => {
    loadData();
    
    if (socket) {
      socket.on('service_request', handleServiceNotification);
    }

    return () => {
      if (socket) {
        socket.off('service_request', handleServiceNotification);
      }
    };
  }, [socket]);

  const loadData = async () => {
    try {
      const chatsResponse = await axios.get('/api/chats');
      
      // 分离顾问和专家
      const advisorsList = chatsResponse.data
        .filter(chat => chat.type === 'private')
        .map(chat => ({
          ...chat,
          id: chat.id,
          username: chat.name,
          avatar: chat.avatar,
          online: chat.online,
          lastSeen: chat.lastSeen,
          professionalField: ['书画鉴定', '古典油画', '现代艺术', '古董鉴赏'][Math.floor(Math.random() * 4)],
          status: ['在线', '忙碌', '离开'][Math.floor(Math.random() * 3)]
        }));
      
      const expertsList = chatsResponse.data
        .filter(chat => chat.type === 'group')
        .map(chat => ({
          ...chat,
          id: chat.id,
          name: chat.name,
          avatar: chat.avatar,
          memberCount: chat.memberCount || 0,
          department: ['珠宝部', '书画部', '古董部', '现代艺术部'][Math.floor(Math.random() * 4)]
        }));
      
      setAdvisors(advisorsList);
      setExperts(expertsList);
    } catch (error) {
      console.error('Failed to load data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleServiceNotification = (data) => {
    if (data.type === 'service_added') {
      // 显示佳士得风格通知
      const notification = document.createElement('div');
      notification.className = 'fixed top-4 left-1/2 transform -translate-x-1/2 warm-gold-bg text-white px-6 py-3 rounded-soft shadow-gentle z-50 soft-slide-in';
      notification.innerHTML = `
        <div class="flex items-center gap-2">
          <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
          </svg>
          <span>${data.message}</span>
        </div>
      `;
      document.body.appendChild(notification);
      
      setTimeout(() => {
        notification.remove();
      }, 4000);
      
      loadData();
    }
  };

  const formatLastSeen = (lastSeen) => {
    if (!lastSeen) return '';
    const date = new Date(lastSeen);
    const now = new Date();
    const diff = now - date;

    if (diff < 60000) return '刚刚';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}分钟前`;
    if (diff < 86400000) return date.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
    return date.toLocaleDateString('zh-CN', { month: '2-digit', day: '2-digit' });
  };

  const getStatusColor = (status) => {
    switch (status) {
      case '在线':
        return 'status-online';
      case '忙碌':
        return 'status-away';
      case '离开':
        return 'status-offline';
      default:
        return 'status-offline';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case '在线':
        return '●';
      case '忙碌':
        return '●';
      case '离开':
        return '●';
      default:
        return '●';
    }
  };

  const renderAdvisorItem = (advisor, index) => (
    <div 
      key={advisor._id || advisor.id} 
      className="soft-card p-5 transition-all duration-300 hover:shadow-gentle hover:scale-105 gentle-fade-in list-item-soft"
      style={{ animationDelay: `${index * 0.05}s` }}
    >
      <div className="flex items-center gap-4">
        <div className="relative">
          <img
            src={advisor.avatar}
            alt={advisor.username}
            className="avatar-soft"
          />
          <div className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-white ${getStatusColor(advisor.status)}`}></div>
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1 mb-1">
            <span className="text-hierarchy-2 text-primary truncate">{advisor.username}</span>
            <span className="text-sm text-muted">·</span>
            <span className="text-sm text-muted">{advisor.professionalField}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className={`text-sm ${getStatusColor(advisor.status)}`}>
              {getStatusIcon(advisor.status)} {advisor.status}
            </span>
            <span className="text-hierarchy-4 text-muted">{formatLastSeen(advisor.lastSeen)}</span>
          </div>
        </div>
        <button className="btn-ghost px-4 py-2 text-sm">
          {advisor.status === '在线' ? '联系' : advisor.status === '忙碌' ? '留言' : '联系'}
        </button>
      </div>
    </div>
  );

  const renderExpertItem = (expert, index) => (
    <div 
      key={expert._id || expert.id} 
      className="soft-card p-5 transition-all duration-300 hover:shadow-gentle hover:scale-105 gentle-fade-in list-item-soft"
      style={{ animationDelay: `${index * 0.05}s` }}
    >
      <div className="flex items-center gap-4">
        <div className="relative">
          <div className="avatar-soft bg-gradient-to-br from-warm-gold to-yellow-600 flex items-center justify-center">
            <span className="text-white text-lg">💎</span>
          </div>
          <div className="absolute -bottom-1 -right-1 bg-soft-blue text-white text-xs rounded-full w-5 h-5 flex items-center justify-center shadow-soft">
            {expert.memberCount}
          </div>
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1 mb-1">
            <span className="text-hierarchy-2 text-primary truncate">{expert.name}</span>
            <span className="text-sm text-muted">·</span>
            <span className="text-sm text-muted">{expert.department}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-hierarchy-4 text-muted">{expert.memberCount}位专家</span>
            <span className="text-hierarchy-4 text-muted">专业团队</span>
          </div>
        </div>
        <button className="btn-ghost px-4 py-2 text-sm">
          联系
        </button>
      </div>
    </div>
  );

  const EmptyState = ({ type }) => (
    <div className="empty-state-soft">
      <svg className="empty-state-icon-soft" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
      </svg>
      <h3 className="empty-state-title-soft">暂无{type === 'advisors' ? '专业顾问' : '专家团队'}</h3>
      <p className="empty-state-desc-soft">去对话页面{type === 'advisors' ? '添加专业顾问' : '创建专家团队'}吧<br/>开始您的{type === 'advisors' ? '专业咨询' : '团队协作'}之旅</p>
    </div>
  );

  return (
    <div className="h-full warm-cream pb-16">
      {/* Header */}
      <div className="soft-blue-bg text-white px-6 py-4 safe-area-pt shadow-gentle">
        <h1 className="text-hierarchy-1 text-white">服务</h1>
      </div>

      {/* Tab Navigation */}
      <div className="warm-cream-card border-b shadow-soft">
        <div className="flex">
          <button
            onClick={() => setActiveTab('advisors')}
            className={`flex-1 py-4 text-center font-medium transition-all duration-300 tab-item-soft ${
              activeTab === 'advisors' ? 'active' : ''
            }`}
          >
            顾问 ({advisors.length})
          </button>
          <button
            onClick={() => setActiveTab('experts')}
            className={`flex-1 py-4 text-center font-medium transition-all duration-300 tab-item-soft ${
              activeTab === 'experts' ? 'active' : ''
            }`}
          >
            专家 ({experts.length})
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto scroll-smooth">
        {loading ? (
          <div className="flex items-center justify-center h-full">
            <div className="w-6 h-6 border-2 border-warm-gold border-t-transparent rounded-full animate-spin"></div>
            <span className="ml-3 text-muted">加载中...</span>
          </div>
        ) : (
          <div className="p-6 space-y-4">
            {activeTab === 'advisors' ? (
              advisors.length === 0 ? (
                <EmptyState type="advisors" />
              ) : (
                advisors.map((advisor, index) => renderAdvisorItem(advisor, index))
              )
            ) : (
              experts.length === 0 ? (
                <EmptyState type="experts" />
              ) : (
                experts.map((expert, index) => renderExpertItem(expert, index))
              )
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default ServicesPage;
