#!/bin/bash

# IM系统SSH部署脚本
# 使用方法: ./deploy.sh [环境] [操作]
# 示例: ./deploy.sh production deploy

set -e

# 配置变量
SSH_HOST="ali-server"
SSH_USER="root"
SSH_PORT="22"
PROJECT_NAME="im-system"
REMOTE_DIR="/opt/${PROJECT_NAME}"
LOCAL_DIR="$(pwd)"

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查SSH连接
check_ssh_connection() {
    log_info "检查SSH连接..."
    if ssh -o ConnectTimeout=10 -o BatchMode=yes ${SSH_HOST} "echo 'SSH连接成功'" >/dev/null 2>&1; then
        log_success "SSH连接正常"
    else
        log_error "SSH连接失败，请检查SSH配置"
        exit 1
    fi
}

# 检查服务器环境
check_server_environment() {
    log_info "检查服务器环境..."
    
    # 检查Node.js
    if ssh ${SSH_HOST} "node --version" >/dev/null 2>&1; then
        NODE_VERSION=$(ssh ${SSH_HOST} "node --version")
        log_success "Node.js已安装: ${NODE_VERSION}"
    else
        log_warning "Node.js未安装，将自动安装..."
        install_nodejs
    fi
    
    # 检查PM2
    if ssh ${SSH_HOST} "pm2 --version" >/dev/null 2>&1; then
        PM2_VERSION=$(ssh ${SSH_HOST} "pm2 --version")
        log_success "PM2已安装: ${PM2_VERSION}"
    else
        log_warning "PM2未安装，将自动安装..."
        install_pm2
    fi
    
    # 检查MongoDB
    if ssh ${SSH_HOST} "mongod --version" >/dev/null 2>&1; then
        log_success "MongoDB已安装"
    else
        log_warning "MongoDB未安装，将自动安装..."
        install_mongodb
    fi
    
    # 检查Nginx
    if ssh ${SSH_HOST} "nginx -v" >/dev/null 2>&1; then
        log_success "Nginx已安装"
    else
        log_warning "Nginx未安装，将自动安装..."
        install_nginx
    fi
}

# 安装Node.js
install_nodejs() {
    log_info "安装Node.js..."
    ssh ${SSH_HOST} << 'EOF'
        curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
        apt-get install -y nodejs
        node --version
        npm --version
EOF
    log_success "Node.js安装完成"
}

# 安装PM2
install_pm2() {
    log_info "安装PM2..."
    ssh ${SSH_HOST} "npm install -g pm2"
    log_success "PM2安装完成"
}

# 安装MongoDB
install_mongodb() {
    log_info "安装MongoDB..."
    ssh ${SSH_HOST} << 'EOF'
        wget -qO - https://www.mongodb.org/static/pgp/server-6.0.asc | apt-key add -
        echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu focal/mongodb-org/6.0 multiverse" | tee /etc/apt/sources.list.d/mongodb-org-6.0.list
        apt-get update
        apt-get install -y mongodb-org
        systemctl start mongod
        systemctl enable mongod
EOF
    log_success "MongoDB安装完成"
}

# 安装Nginx
install_nginx() {
    log_info "安装Nginx..."
    ssh ${SSH_HOST} << 'EOF'
        apt-get update
        apt-get install -y nginx
        systemctl start nginx
        systemctl enable nginx
EOF
    log_success "Nginx安装完成"
}

# 创建项目目录
create_project_directory() {
    log_info "创建项目目录..."
    ssh ${SSH_HOST} "mkdir -p ${REMOTE_DIR}/{logs,uploads,ssl}"
    log_success "项目目录创建完成"
}

# 上传项目文件
upload_project_files() {
    log_info "上传项目文件..."
    
    # 创建临时目录
    TEMP_DIR="/tmp/${PROJECT_NAME}-$(date +%s)"
    mkdir -p ${TEMP_DIR}
    
    # 复制项目文件
    cp -r app_production.js package_production.json ecosystem.config.js Dockerfile.production docker-compose.yml nginx.conf env.example README_PRODUCTION.md ${TEMP_DIR}/
    
    # 复制前端文件
    if [ -d "frontend_production" ]; then
        cp -r frontend_production ${TEMP_DIR}/
    fi
    
    # 上传到服务器
    scp -r ${TEMP_DIR}/* ${SSH_HOST}:${REMOTE_DIR}/
    
    # 清理临时目录
    rm -rf ${TEMP_DIR}
    
    log_success "项目文件上传完成"
}

# 安装项目依赖
install_dependencies() {
    log_info "安装项目依赖..."
    ssh ${SSH_HOST} << EOF
        cd ${REMOTE_DIR}
        npm install --production
        if [ -d "frontend_production" ]; then
            cd frontend_production
            npm install
            npm run build
        fi
EOF
    log_success "依赖安装完成"
}

# 配置环境变量
setup_environment() {
    log_info "配置环境变量..."
    ssh ${SSH_HOST} << EOF
        cd ${REMOTE_DIR}
        cp env.example .env
        # 生成随机JWT密钥
        JWT_SECRET=\$(openssl rand -base64 32)
        sed -i "s/your_super_secure_jwt_secret_key_2024/\${JWT_SECRET}/g" .env
        # 设置生产环境配置
        sed -i 's/NODE_ENV=development/NODE_ENV=production/g' .env
        sed -i 's|FRONTEND_URL=http://localhost:3000|FRONTEND_URL=http://8.148.77.51|g' .env
EOF
    log_success "环境变量配置完成"
}

# 配置Nginx
setup_nginx() {
    log_info "配置Nginx..."
    ssh ${SSH_HOST} << EOF
        # 备份原配置
        cp /etc/nginx/nginx.conf /etc/nginx/nginx.conf.backup
        
        # 复制新配置
        cp ${REMOTE_DIR}/nginx.conf /etc/nginx/nginx.conf
        
        # 测试配置
        nginx -t
        
        # 重启Nginx
        systemctl restart nginx
        systemctl enable nginx
EOF
    log_success "Nginx配置完成"
}

# 启动服务
start_services() {
    log_info "启动服务..."
    ssh ${SSH_HOST} << EOF
        cd ${REMOTE_DIR}
        
        # 启动MongoDB
        systemctl start mongod
        
        # 启动应用
        pm2 start ecosystem.config.js --env production
        
        # 保存PM2配置
        pm2 save
        pm2 startup
EOF
    log_success "服务启动完成"
}

# 检查服务状态
check_services() {
    log_info "检查服务状态..."
    ssh ${SSH_HOST} << EOF
        echo "=== PM2状态 ==="
        pm2 status
        
        echo "=== MongoDB状态 ==="
        systemctl status mongod --no-pager
        
        echo "=== Nginx状态 ==="
        systemctl status nginx --no-pager
        
        echo "=== 端口监听 ==="
        netstat -tlnp | grep -E ':(80|3001|27017)'
EOF
    log_success "服务状态检查完成"
}

# 显示访问信息
show_access_info() {
    log_success "部署完成！"
    echo ""
    echo "=== 访问信息 ==="
    echo "前端地址: http://8.148.77.51"
    echo "后端API: http://8.148.77.51/api"
    echo "健康检查: http://8.148.77.51/health"
    echo ""
    echo "=== 管理命令 ==="
    echo "查看日志: ssh ${SSH_HOST} 'pm2 logs'"
    echo "重启服务: ssh ${SSH_HOST} 'pm2 restart all'"
    echo "停止服务: ssh ${SSH_HOST} 'pm2 stop all'"
    echo "查看状态: ssh ${SSH_HOST} 'pm2 status'"
    echo ""
}

# 停止服务
stop_services() {
    log_info "停止服务..."
    ssh ${SSH_HOST} << EOF
        cd ${REMOTE_DIR}
        pm2 stop all
        pm2 delete all
EOF
    log_success "服务已停止"
}

# 查看日志
view_logs() {
    log_info "查看服务日志..."
    ssh ${SSH_HOST} << EOF
        cd ${REMOTE_DIR}
        pm2 logs --lines 50
EOF
}

# 重启服务
restart_services() {
    log_info "重启服务..."
    ssh ${SSH_HOST} << EOF
        cd ${REMOTE_DIR}
        pm2 restart all
EOF
    log_success "服务重启完成"
}

# 主函数
main() {
    case "${1:-deploy}" in
        "deploy")
            log_info "开始部署IM系统到SSH主机..."
            check_ssh_connection
            check_server_environment
            create_project_directory
            upload_project_files
            install_dependencies
            setup_environment
            setup_nginx
            start_services
            check_services
            show_access_info
            ;;
        "stop")
            stop_services
            ;;
        "restart")
            restart_services
            ;;
        "logs")
            view_logs
            ;;
        "status")
            check_services
            ;;
        "update")
            log_info "更新应用..."
            upload_project_files
            install_dependencies
            restart_services
            log_success "应用更新完成"
            ;;
        *)
            echo "使用方法: $0 [deploy|stop|restart|logs|status|update]"
            echo ""
            echo "命令说明:"
            echo "  deploy  - 完整部署应用"
            echo "  stop    - 停止服务"
            echo "  restart - 重启服务"
            echo "  logs    - 查看日志"
            echo "  status  - 查看状态"
            echo "  update  - 更新应用"
            exit 1
            ;;
    esac
}

# 执行主函数
main "$@"
