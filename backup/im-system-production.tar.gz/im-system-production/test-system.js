const axios = require('axios');
const WebSocket = require('ws');

// 测试配置
const BASE_URL = 'http://8.148.77.51';
const API_URL = `${BASE_URL}/api`;
const WS_URL = 'ws://8.148.77.51/socket.io';

// 测试结果
const testResults = {
  passed: 0,
  failed: 0,
  tests: []
};

// 测试用户
const testUsers = {
  user1: { username: 'testuser1', password: 'password123' },
  user2: { username: 'testuser2', password: 'password123' }
};

// 工具函数
function logTest(testName, passed, message = '') {
  const status = passed ? '✅ PASS' : '❌ FAIL';
  console.log(`${status} ${testName}${message ? ': ' + message : ''}`);
  
  testResults.tests.push({ name: testName, passed, message });
  if (passed) {
    testResults.passed++;
  } else {
    testResults.failed++;
  }
}

// 等待函数
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// 1. 健康检查测试
async function testHealthCheck() {
  try {
    const response = await axios.get(`${BASE_URL}/health`);
    logTest('健康检查', response.status === 200, `状态码: ${response.status}`);
    return true;
  } catch (error) {
    logTest('健康检查', false, error.message);
    return false;
  }
}

// 2. 用户注册测试
async function testUserRegistration() {
  try {
    // 注册用户1
    const response1 = await axios.post(`${API_URL}/register`, testUsers.user1);
    logTest('用户1注册', response1.status === 201, '注册成功');
    
    // 注册用户2
    const response2 = await axios.post(`${API_URL}/register`, testUsers.user2);
    logTest('用户2注册', response2.status === 201, '注册成功');
    
    return true;
  } catch (error) {
    if (error.response?.status === 400 && error.response?.data?.message?.includes('已存在')) {
      logTest('用户注册', true, '用户已存在（正常）');
      return true;
    }
    logTest('用户注册', false, error.response?.data?.message || error.message);
    return false;
  }
}

// 3. 用户登录测试
async function testUserLogin() {
  try {
    const response = await axios.post(`${API_URL}/login`, testUsers.user1);
    logTest('用户登录', response.status === 200, '登录成功');
    
    if (response.data.token) {
      testUsers.user1.token = response.data.token;
      testUsers.user1.id = response.data.user.id;
      logTest('JWT令牌获取', true, '令牌有效');
    } else {
      logTest('JWT令牌获取', false, '未获取到令牌');
    }
    
    return true;
  } catch (error) {
    logTest('用户登录', false, error.response?.data?.message || error.message);
    return false;
  }
}

// 4. 用户搜索测试
async function testUserSearch() {
  try {
    const response = await axios.get(`${API_URL}/users/search`, {
      params: { username: 'testuser2' },
      headers: { Authorization: `Bearer ${testUsers.user1.token}` }
    });
    
    logTest('用户搜索', response.status === 200, '搜索成功');
    
    if (response.data.users && response.data.users.length > 0) {
      testUsers.user2.id = response.data.users[0].id;
      logTest('搜索结果', true, `找到用户: ${response.data.users[0].username}`);
    } else {
      logTest('搜索结果', false, '未找到目标用户');
    }
    
    return true;
  } catch (error) {
    logTest('用户搜索', false, error.response?.data?.message || error.message);
    return false;
  }
}

// 5. 好友请求测试
async function testFriendRequest() {
  try {
    const response = await axios.post(`${API_URL}/friend-requests`, {
      receiverId: testUsers.user2.id
    }, {
      headers: { Authorization: `Bearer ${testUsers.user1.token}` }
    });
    
    logTest('发送好友请求', response.status === 201, '请求发送成功');
    return true;
  } catch (error) {
    if (error.response?.status === 400 && error.response?.data?.message?.includes('已发送')) {
      logTest('发送好友请求', true, '请求已存在（正常）');
      return true;
    }
    logTest('发送好友请求', false, error.response?.data?.message || error.message);
    return false;
  }
}

// 6. 获取好友请求测试
async function testGetFriendRequests() {
  try {
    // 用户2登录
    const loginResponse = await axios.post(`${API_URL}/login`, testUsers.user2);
    testUsers.user2.token = loginResponse.data.token;
    testUsers.user2.id = loginResponse.data.user.id;
    
    const response = await axios.get(`${API_URL}/friend-requests`, {
      headers: { Authorization: `Bearer ${testUsers.user2.token}` }
    });
    
    logTest('获取好友请求', response.status === 200, '获取成功');
    
    if (response.data.received && response.data.received.length > 0) {
      testUsers.friendRequestId = response.data.received[0].id;
      logTest('好友请求数据', true, `收到${response.data.received.length}个请求`);
    } else {
      logTest('好友请求数据', false, '未收到好友请求');
    }
    
    return true;
  } catch (error) {
    logTest('获取好友请求', false, error.response?.data?.message || error.message);
    return false;
  }
}

// 7. 接受好友请求测试
async function testAcceptFriendRequest() {
  try {
    const response = await axios.put(`${API_URL}/friend-requests/${testUsers.friendRequestId}`, {
      status: 'accepted'
    }, {
      headers: { Authorization: `Bearer ${testUsers.user2.token}` }
    });
    
    logTest('接受好友请求', response.status === 200, '接受成功');
    return true;
  } catch (error) {
    logTest('接受好友请求', false, error.response?.data?.message || error.message);
    return false;
  }
}

// 8. 获取好友列表测试
async function testGetFriends() {
  try {
    const response = await axios.get(`${API_URL}/friends`, {
      headers: { Authorization: `Bearer ${testUsers.user1.token}` }
    });
    
    logTest('获取好友列表', response.status === 200, '获取成功');
    
    if (response.data.friends && response.data.friends.length > 0) {
      logTest('好友关系', true, `有${response.data.friends.length}个好友`);
    } else {
      logTest('好友关系', false, '好友列表为空');
    }
    
    return true;
  } catch (error) {
    logTest('获取好友列表', false, error.response?.data?.message || error.message);
    return false;
  }
}

// 9. 创建群组测试
async function testCreateGroup() {
  try {
    const response = await axios.post(`${API_URL}/groups/create`, {
      name: '测试群组',
      description: '这是一个测试群组'
    }, {
      headers: { Authorization: `Bearer ${testUsers.user1.token}` }
    });
    
    logTest('创建群组', response.status === 201, '创建成功');
    
    if (response.data.group && response.data.group.id) {
      testUsers.groupId = response.data.group.id;
      logTest('群组数据', true, `群组ID: ${response.data.group.id}`);
    } else {
      logTest('群组数据', false, '未获取到群组ID');
    }
    
    return true;
  } catch (error) {
    logTest('创建群组', false, error.response?.data?.message || error.message);
    return false;
  }
}

// 10. 获取群组列表测试
async function testGetGroups() {
  try {
    const response = await axios.get(`${API_URL}/groups/my`, {
      headers: { Authorization: `Bearer ${testUsers.user1.token}` }
    });
    
    logTest('获取群组列表', response.status === 200, '获取成功');
    
    if (response.data.groups && response.data.groups.length > 0) {
      logTest('群组数据', true, `有${response.data.groups.length}个群组`);
    } else {
      logTest('群组数据', false, '群组列表为空');
    }
    
    return true;
  } catch (error) {
    logTest('获取群组列表', false, error.response?.data?.message || error.message);
    return false;
  }
}

// 11. 发送群组消息测试
async function testSendGroupMessage() {
  try {
    const response = await axios.post(`${API_URL}/groups/${testUsers.groupId}/messages`, {
      content: '这是一条测试消息',
      messageType: 'text'
    }, {
      headers: { Authorization: `Bearer ${testUsers.user1.token}` }
    });
    
    logTest('发送群组消息', response.status === 201, '发送成功');
    return true;
  } catch (error) {
    logTest('发送群组消息', false, error.response?.data?.message || error.message);
    return false;
  }
}

// 12. 获取群组消息测试
async function testGetGroupMessages() {
  try {
    const response = await axios.get(`${API_URL}/groups/${testUsers.groupId}/messages`, {
      headers: { Authorization: `Bearer ${testUsers.user1.token}` }
    });
    
    logTest('获取群组消息', response.status === 200, '获取成功');
    
    if (response.data.messages && response.data.messages.length > 0) {
      logTest('消息数据', true, `有${response.data.messages.length}条消息`);
    } else {
      logTest('消息数据', false, '消息列表为空');
    }
    
    return true;
  } catch (error) {
    logTest('获取群组消息', false, error.response?.data?.message || error.message);
    return false;
  }
}

// 13. WebSocket连接测试
async function testWebSocketConnection() {
  return new Promise((resolve) => {
    try {
      const ws = new WebSocket(`${WS_URL}?token=${testUsers.user1.token}`);
      
      let connected = false;
      
      ws.on('open', () => {
        connected = true;
        logTest('WebSocket连接', true, '连接成功');
        ws.close();
        resolve(true);
      });
      
      ws.on('error', (error) => {
        logTest('WebSocket连接', false, error.message);
        resolve(false);
      });
      
      // 5秒超时
      setTimeout(() => {
        if (!connected) {
          logTest('WebSocket连接', false, '连接超时');
          ws.close();
          resolve(false);
        }
      }, 5000);
      
    } catch (error) {
      logTest('WebSocket连接', false, error.message);
      resolve(false);
    }
  });
}

// 14. 文件上传测试
async function testFileUpload() {
  try {
    // 创建一个简单的测试文件
    const FormData = require('form-data');
    const fs = require('fs');
    
    const testFile = 'test.txt';
    fs.writeFileSync(testFile, '这是一个测试文件');
    
    const form = new FormData();
    form.append('file', fs.createReadStream(testFile));
    
    const response = await axios.post(`${API_URL}/upload/file`, form, {
      headers: {
        ...form.getHeaders(),
        Authorization: `Bearer ${testUsers.user1.token}`
      }
    });
    
    // 清理测试文件
    fs.unlinkSync(testFile);
    
    logTest('文件上传', response.status === 201, '上传成功');
    
    if (response.data.filePath) {
      logTest('文件路径', true, `路径: ${response.data.filePath}`);
    } else {
      logTest('文件路径', false, '未获取到文件路径');
    }
    
    return true;
  } catch (error) {
    logTest('文件上传', false, error.response?.data?.message || error.message);
    return false;
  }
}

// 主测试函数
async function runAllTests() {
  console.log('🚀 开始IM系统功能测试...\n');
  
  // 基础功能测试
  await testHealthCheck();
  await sleep(1000);
  
  // 用户功能测试
  await testUserRegistration();
  await sleep(1000);
  
  await testUserLogin();
  await sleep(1000);
  
  await testUserSearch();
  await sleep(1000);
  
  // 好友功能测试
  await testFriendRequest();
  await sleep(1000);
  
  await testGetFriendRequests();
  await sleep(1000);
  
  await testAcceptFriendRequest();
  await sleep(1000);
  
  await testGetFriends();
  await sleep(1000);
  
  // 群组功能测试
  await testCreateGroup();
  await sleep(1000);
  
  await testGetGroups();
  await sleep(1000);
  
  await testSendGroupMessage();
  await sleep(1000);
  
  await testGetGroupMessages();
  await sleep(1000);
  
  // 高级功能测试
  await testWebSocketConnection();
  await sleep(1000);
  
  await testFileUpload();
  
  // 输出测试结果
  console.log('\n📊 测试结果汇总:');
  console.log('================================');
  console.log(`✅ 通过: ${testResults.passed}`);
  console.log(`❌ 失败: ${testResults.failed}`);
  console.log(`📈 成功率: ${((testResults.passed / (testResults.passed + testResults.failed)) * 100).toFixed(1)}%`);
  
  if (testResults.failed === 0) {
    console.log('\n🎉 所有测试通过！系统功能正常！');
  } else {
    console.log('\n⚠️  部分测试失败，请检查系统配置。');
    console.log('\n失败的测试:');
    testResults.tests
      .filter(test => !test.passed)
      .forEach(test => console.log(`  - ${test.name}: ${test.message}`));
  }
  
  console.log('\n🌐 访问地址:');
  console.log(`前端: ${BASE_URL}`);
  console.log(`API: ${API_URL}`);
  console.log(`健康检查: ${BASE_URL}/health`);
}

// 运行测试
if (require.main === module) {
  runAllTests().catch(console.error);
}

module.exports = { runAllTests };
