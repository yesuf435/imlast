# IM即时通讯系统 - 安装说明

## 🎯 系统概述

这是一个功能完整的现代化即时通讯系统，包含以下核心功能：

### ✅ 已实现功能
- **用户认证**: 注册、登录、JWT认证
- **好友系统**: 搜索用户、好友请求、好友管理
- **群组功能**: 创建群组、邀请好友、群成员管理
- **实时消息**: 文本、图片、文件、语音消息
- **在线状态**: 实时显示用户在线/离线状态
- **消息推送**: Socket.io实时消息推送
- **文件上传**: 支持多种文件类型
- **安全防护**: 多层安全防护，生产就绪

### 🛠 技术栈
- **后端**: Node.js + Express + Socket.io + MongoDB
- **前端**: React 18 + TypeScript + Tailwind CSS
- **部署**: Docker + Nginx + PM2

## 🚀 快速开始

### 1. 环境准备

**最低要求：**
- 服务器: 2GB内存，10GB存储
- 系统: Ubuntu 18.04+ / CentOS 7+
- 网络: 公网IP，开放80端口

**推荐配置：**
- 服务器: 4GB内存，50GB存储
- 系统: Ubuntu 20.04 LTS
- 网络: 公网IP，支持HTTPS

### 2. 一键部署

**Windows用户：**
```bash
# 双击运行
quick-deploy.bat
```

**Linux用户：**
```bash
# 给权限并运行
chmod +x deploy.sh
./deploy.sh deploy
```

### 3. Docker部署

```bash
# 启动所有服务
docker-compose up -d

# 查看状态
docker-compose ps
```

## 📋 详细安装步骤

### 步骤1: 服务器环境检查

```bash
# 检查系统版本
cat /etc/os-release

# 检查内存和磁盘
free -h
df -h

# 检查网络连接
ping google.com
```

### 步骤2: 安装依赖软件

**安装Node.js:**
```bash
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs
node --version
npm --version
```

**安装MongoDB:**
```bash
wget -qO - https://www.mongodb.org/static/pgp/server-6.0.asc | sudo apt-key add -
echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu focal/mongodb-org/6.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-6.0.list
sudo apt-get update
sudo apt-get install -y mongodb-org
sudo systemctl start mongod
sudo systemctl enable mongod
```

**安装Nginx:**
```bash
sudo apt-get update
sudo apt-get install -y nginx
sudo systemctl start nginx
sudo systemctl enable nginx
```

**安装PM2:**
```bash
sudo npm install -g pm2
pm2 --version
```

### 步骤3: 部署应用

**上传文件:**
```bash
# 创建目录
sudo mkdir -p /opt/im-system
sudo chown $USER:$USER /opt/im-system

# 上传文件（使用scp或sftp）
scp -r im-system-production/* user@server:/opt/im-system/
```

**安装依赖:**
```bash
cd /opt/im-system
npm install --production
```

**配置环境:**
```bash
# 复制环境配置
cp .env.example .env

# 编辑配置
nano .env
```

**启动服务:**
```bash
# 启动MongoDB
sudo systemctl start mongod

# 启动应用
pm2 start ecosystem.config.js --env production
pm2 save
pm2 startup
```

### 步骤4: 配置Nginx

```bash
# 备份原配置
sudo cp /etc/nginx/nginx.conf /etc/nginx/nginx.conf.backup

# 复制新配置
sudo cp nginx.conf /etc/nginx/nginx.conf

# 测试配置
sudo nginx -t

# 重启Nginx
sudo systemctl restart nginx
```

### 步骤5: 验证部署

```bash
# 检查服务状态
pm2 status
sudo systemctl status mongod
sudo systemctl status nginx

# 检查端口
netstat -tlnp | grep -E ':(80|3001|27017)'

# 测试访问
curl http://localhost/health
curl http://localhost/api/users
```

## 🔧 配置说明

### 环境变量配置

编辑 `.env` 文件：

```env
# 服务器配置
NODE_ENV=production
PORT=3001
HOST=0.0.0.0

# 数据库配置
MONGO_URL=mongodb://localhost:27017
DB_NAME=im_production

# JWT配置（请修改为随机字符串）
JWT_SECRET=your_super_secure_jwt_secret_key_2024
JWT_EXPIRES_IN=7d

# 前端地址（请修改为您的域名）
FRONTEND_URL=http://your-domain.com

# 安全配置
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
LOGIN_RATE_LIMIT_MAX=5
```

### 重要配置项

1. **JWT_SECRET**: 必须修改为随机字符串
2. **FRONTEND_URL**: 修改为您的实际域名
3. **MONGO_URL**: 如果MongoDB不在本地，请修改连接地址

## 🛡️ 安全配置

### 1. 防火墙设置

```bash
# 安装ufw
sudo apt install ufw

# 配置规则
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow 80
sudo ufw allow 443

# 启用防火墙
sudo ufw enable
```

### 2. SSL证书配置

```bash
# 安装certbot
sudo apt install certbot python3-certbot-nginx

# 获取证书
sudo certbot --nginx -d your-domain.com

# 自动续期
sudo crontab -e
# 添加: 0 12 * * * /usr/bin/certbot renew --quiet
```

### 3. 数据库安全

```bash
# 连接MongoDB
mongosh

# 创建管理员用户
use admin
db.createUser({
  user: "admin",
  pwd: "secure_password",
  roles: ["userAdminAnyDatabase", "dbAdminAnyDatabase", "readWriteAnyDatabase"]
})

# 启用认证
sudo nano /etc/mongod.conf
# 添加: security.authorization: enabled

# 重启MongoDB
sudo systemctl restart mongod
```

## 📊 监控和维护

### 1. 服务监控

```bash
# PM2监控
pm2 monit

# 系统监控
htop
iostat -x 1

# 日志查看
pm2 logs
tail -f /var/log/nginx/access.log
```

### 2. 备份策略

```bash
# 数据库备份
mongodump --db im_production --out /backup/$(date +%Y%m%d)

# 应用备份
tar -czf /backup/app-$(date +%Y%m%d).tar.gz /opt/im-system

# 自动备份脚本
sudo crontab -e
# 添加: 0 2 * * * /path/to/backup.sh
```

### 3. 日志管理

```bash
# 安装日志轮转
pm2 install pm2-logrotate

# 配置日志轮转
pm2 set pm2-logrotate:max_size 10M
pm2 set pm2-logrotate:retain 7
pm2 set pm2-logrotate:compress true
```

## 🐛 常见问题

### 1. Node.js版本问题

**问题**: `GLIBCXX_3.4.21 not found`

**解决**: 安装兼容的Node.js版本
```bash
# 卸载旧版本
sudo apt remove nodejs npm

# 安装Node.js 16
curl -fsSL https://deb.nodesource.com/setup_16.x | sudo -E bash -
sudo apt-get install -y nodejs
```

### 2. MongoDB连接失败

**问题**: 无法连接MongoDB

**解决**: 检查服务状态和配置
```bash
# 检查服务
sudo systemctl status mongod

# 检查端口
netstat -tlnp | grep 27017

# 重启服务
sudo systemctl restart mongod
```

### 3. 端口被占用

**问题**: 端口80或3001被占用

**解决**: 查找并释放端口
```bash
# 查找占用进程
sudo lsof -i :80
sudo lsof -i :3001

# 杀死进程
sudo kill -9 PID
```

### 4. Nginx配置错误

**问题**: Nginx启动失败

**解决**: 检查配置文件
```bash
# 测试配置
sudo nginx -t

# 查看错误日志
sudo tail -f /var/log/nginx/error.log

# 恢复备份配置
sudo cp /etc/nginx/nginx.conf.backup /etc/nginx/nginx.conf
```

## 📞 技术支持

### 检查清单

部署完成后，请确认：

- [ ] 所有服务正常运行
- [ ] 端口80和3001可访问
- [ ] 数据库连接正常
- [ ] 前端页面可访问
- [ ] API接口响应正常
- [ ] WebSocket连接正常
- [ ] 文件上传功能正常
- [ ] 用户注册登录正常
- [ ] 好友功能正常
- [ ] 群组功能正常
- [ ] 消息发送接收正常

### 联系方式

如遇到问题，请提供：
1. 服务器系统版本
2. 错误日志信息
3. 服务状态截图
4. 网络连接情况

---

**恭喜！** 您已成功部署IM即时通讯系统。现在可以开始使用这个功能完整的聊天应用了！
