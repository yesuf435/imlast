# IM即时通讯系统 - 生产部署指南

## 📦 部署包内容

```
im-system-production/
├── app_production.js          # 生产版后端服务
├── package.json               # 依赖配置
├── ecosystem.config.js        # PM2集群配置
├── nginx.conf                 # Nginx配置
├── .env                       # 环境变量配置
├── docker-compose.yml         # Docker编排
├── Dockerfile                 # Docker镜像
├── deploy.sh                  # Linux部署脚本
├── deploy.bat                 # Windows部署脚本
├── quick-deploy.bat           # 快速部署脚本
├── README.md                  # 详细文档
├── DEPLOYMENT_GUIDE.md        # 部署指南
└── frontend_production/       # 前端代码
    ├── src/                   # 源代码
    ├── package.json           # 前端依赖
    └── vite.config.ts         # 构建配置
```

## 🚀 快速部署

### 方式一：一键部署（推荐）

**Windows用户：**
```bash
# 双击运行或命令行执行
quick-deploy.bat
```

**Linux用户：**
```bash
# 给脚本执行权限
chmod +x deploy.sh

# 执行部署
./deploy.sh deploy
```

### 方式二：Docker部署

```bash
# 构建并启动所有服务
docker-compose up -d

# 查看服务状态
docker-compose ps

# 查看日志
docker-compose logs -f
```

### 方式三：手动部署

1. **上传文件到服务器**
```bash
scp -r im-system-production/* user@server:/opt/im-system/
```

2. **安装依赖**
```bash
cd /opt/im-system
npm install --production
```

3. **配置环境**
```bash
# 编辑环境变量
nano .env

# 配置Nginx
cp nginx.conf /etc/nginx/nginx.conf
nginx -t
systemctl restart nginx
```

4. **启动服务**
```bash
# 启动MongoDB
systemctl start mongod

# 启动应用
pm2 start ecosystem.config.js --env production
pm2 save
```

## 🔧 环境要求

### 服务器要求
- **操作系统**: Ubuntu 18.04+ / CentOS 7+
- **内存**: 最少2GB，推荐4GB+
- **存储**: 最少10GB可用空间
- **网络**: 公网IP，开放80端口

### 软件要求
- **Node.js**: 16.0.0+
- **MongoDB**: 4.4+
- **Nginx**: 1.18+
- **PM2**: 5.0+（可选）

## 📋 部署前检查

### 1. 服务器环境检查
```bash
# 检查系统版本
cat /etc/os-release

# 检查内存
free -h

# 检查磁盘空间
df -h

# 检查网络
ping google.com
```

### 2. 端口检查
```bash
# 检查端口占用
netstat -tlnp | grep -E ':(80|3001|27017)'

# 检查防火墙
ufw status
```

### 3. 依赖检查
```bash
# 检查Node.js
node --version

# 检查MongoDB
mongod --version

# 检查Nginx
nginx -v
```

## ⚙️ 配置说明

### 环境变量配置 (.env)
```env
# 服务器配置
NODE_ENV=production
PORT=3001
HOST=0.0.0.0

# 数据库配置
MONGO_URL=mongodb://localhost:27017
DB_NAME=im_production

# JWT配置
JWT_SECRET=your_super_secure_jwt_secret_key_2024
JWT_EXPIRES_IN=7d

# 前端地址
FRONTEND_URL=http://your-domain.com

# 安全配置
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
LOGIN_RATE_LIMIT_MAX=5
```

### Nginx配置要点
- 反向代理到后端服务 (3001端口)
- Socket.io WebSocket支持
- 静态文件服务
- Gzip压缩
- 安全头设置

### PM2配置要点
- 集群模式运行
- 自动重启
- 日志管理
- 内存限制
- 健康检查

## 🔍 部署后验证

### 1. 服务状态检查
```bash
# 检查PM2状态
pm2 status

# 检查MongoDB
systemctl status mongod

# 检查Nginx
systemctl status nginx

# 检查端口监听
netstat -tlnp | grep -E ':(80|3001|27017)'
```

### 2. 功能测试
```bash
# 健康检查
curl http://your-domain.com/health

# API测试
curl http://your-domain.com/api/users

# 前端访问
curl http://your-domain.com
```

### 3. 日志检查
```bash
# 应用日志
pm2 logs

# Nginx日志
tail -f /var/log/nginx/access.log
tail -f /var/log/nginx/error.log

# MongoDB日志
tail -f /var/log/mongodb/mongod.log
```

## 🛠 管理命令

### 应用管理
```bash
# 启动服务
pm2 start ecosystem.config.js --env production

# 停止服务
pm2 stop all

# 重启服务
pm2 restart all

# 查看状态
pm2 status

# 查看日志
pm2 logs

# 监控
pm2 monit
```

### 数据库管理
```bash
# 启动MongoDB
systemctl start mongod

# 停止MongoDB
systemctl stop mongod

# 重启MongoDB
systemctl restart mongod

# 连接数据库
mongosh
```

### Nginx管理
```bash
# 测试配置
nginx -t

# 重载配置
nginx -s reload

# 重启Nginx
systemctl restart nginx

# 查看状态
systemctl status nginx
```

## 🔒 安全配置

### 1. 防火墙设置
```bash
# 开放必要端口
ufw allow 22    # SSH
ufw allow 80    # HTTP
ufw allow 443   # HTTPS (如果使用SSL)

# 启用防火墙
ufw enable
```

### 2. SSL证书配置
```bash
# 使用Let's Encrypt
apt install certbot python3-certbot-nginx
certbot --nginx -d your-domain.com
```

### 3. 数据库安全
```bash
# 启用MongoDB认证
mongosh
use admin
db.createUser({
  user: "admin",
  pwd: "secure_password",
  roles: ["userAdminAnyDatabase", "dbAdminAnyDatabase", "readWriteAnyDatabase"]
})
```

## 📊 监控和维护

### 1. 系统监控
```bash
# 系统资源
htop
iostat
df -h

# 网络监控
iftop
netstat -i
```

### 2. 应用监控
```bash
# PM2监控
pm2 monit

# 日志轮转
pm2 install pm2-logrotate
```

### 3. 备份策略
```bash
# 数据库备份
mongodump --db im_production --out /backup/$(date +%Y%m%d)

# 应用备份
tar -czf /backup/app-$(date +%Y%m%d).tar.gz /opt/im-system
```

## 🐛 故障排除

### 常见问题

1. **Node.js版本不兼容**
```bash
# 安装Node.js 16+
curl -fsSL https://deb.nodesource.com/setup_16.x | sudo -E bash -
sudo apt-get install -y nodejs
```

2. **MongoDB连接失败**
```bash
# 检查MongoDB服务
systemctl status mongod

# 检查配置文件
cat /etc/mongod.conf

# 重启服务
systemctl restart mongod
```

3. **端口被占用**
```bash
# 查找占用进程
lsof -i :3001

# 杀死进程
kill -9 PID
```

4. **Nginx配置错误**
```bash
# 测试配置
nginx -t

# 查看错误日志
tail -f /var/log/nginx/error.log
```

## 📞 技术支持

如遇到问题，请检查：
1. 服务器日志
2. 应用日志
3. 网络连接
4. 端口占用
5. 权限设置

## 📄 许可证

MIT License

---

**注意**: 这是一个生产就绪的IM系统，请根据实际需求调整配置和安全设置。
